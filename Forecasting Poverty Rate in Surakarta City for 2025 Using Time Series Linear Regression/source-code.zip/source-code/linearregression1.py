import os
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.dummy import DummyRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error

# -------------------- Pengaturan output --------------------
OUT = Path("./output_linear_main")
OUT.mkdir(exist_ok=True, parents=True)

# Agar plotting tidak menggantung di beberapa environment
SHOW_PLOTS = True
def maybe_show():
    if SHOW_PLOTS:
        plt.show()
    else:
        plt.close()

# -------------------- Data --------------------
def load_data():
    df = pd.DataFrame({
        "Tahun":[2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024],
        # JIKA INI DALAM "JIWA", GUNAKAN NAMA SEMENTARA:
        "Jumlah_jiwa":[59680,55920,55710,55910,54890,46990,45180,47030,48790,45900,43890,43280],
        "Persen":[11.74,10.95,10.89,10.88,10.65,9.08,8.70,9.03,9.40,8.84,8.44,8.31],
    }).sort_values("Tahun").reset_index(drop=True)

    # KONVERSI ke ribu jiwa
    df["Jumlah_ribu"] = pd.to_numeric(df["Jumlah_jiwa"], errors="coerce") / 1000.0
    df.drop(columns=["Jumlah_jiwa"], inplace=True)  # boleh dihapus agar tidak rancu

    # validasi
    for c in ["Jumlah_ribu","Persen"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if df[["Jumlah_ribu","Persen"]].isna().any().any():
        raise ValueError("Ada NaN di data mentah. Periksa input.")

    return df

# -------------------- Utils --------------------
def rmse(y_true, y_pred):
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))

def mape_percent(y_true, y_pred):
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()
    return float(np.mean(np.abs((y_true - y_pred) / y_true)) * 100)

def score_report(y_true, y_pred):
    return {"MAE": mean_absolute_error(y_true, y_pred),
            "RMSE": rmse(y_true, y_pred),
            "MAPE(%)": mape_percent(y_true, y_pred)}

# -------------------- Feature Builder --------------------
def build_features(df_in, target):
    """
    Fitur time-series aman (tanpa GK):
      - target_lag1, target_lag2
      - target_roll2 (rata2 dari t-1 & t-2)
      - trend t
      - cross 1 buah:
         * Target=Persen      -> Jumlah_lag1
         * Target=Jumlah_ribu -> Persen_lag1
    """
    out = df_in.copy()

    out[f"{target}_lag1"] = out[target].shift(1)
    out[f"{target}_lag2"] = out[target].shift(2)
    out[f"{target}_roll2"] = out[target].shift(1).rolling(2).mean()
    out["t"] = np.arange(len(out))

    if target == "Persen":
        out["Jumlah_lag1"] = out["Jumlah_ribu"].shift(1)
    elif target == "Jumlah_ribu":
        out["Persen_lag1"] = out["Persen"].shift(1)

    # drop NA di fitur saja
    drop_cols = ["Tahun","Jumlah_ribu","Persen", target]
    feature_cols = [c for c in out.columns if c not in drop_cols]
    out = out.dropna(subset=feature_cols).reset_index(drop=True)

    X, y, years = out[feature_cols], out[target], out["Tahun"]
    return X, y, years, feature_cols

# -------------------- Model: Linear --------------------
def fit_linear(X_np, y_np):
    lin = LinearRegression()
    lin.fit(X_np, y_np)
    return lin

# -------------------- Evaluasi holdout 2024 --------------------
def evaluate_holdout_2024(df_base, target):
    X, y, years, feats = build_features(df_base, target)
    test_mask = (years == 2024)
    if test_mask.sum() != 1:
        raise RuntimeError("Holdout 2024 tidak ditemukan.")

    X_train, y_train = X[~test_mask], y[~test_mask]
    X_test,  y_test  = X[test_mask],  y[test_mask]

    X_train_np, y_train_np = X_train.to_numpy(), y_train.to_numpy().ravel()
    X_test_np,  y_test_np  = X_test.to_numpy(),  y_test.to_numpy().ravel()

    # Baseline Naive: gunakan target_lag1
    lag1_col = f"{target}_lag1"
    y_pred_naive = X_test[lag1_col].to_numpy()
    if np.isnan(y_pred_naive).any():
        y_pred_naive = np.nan_to_num(y_pred_naive, nan=float(np.nanmean(X_train[lag1_col].values)))

    dum = DummyRegressor(strategy="mean").fit(X_train_np, y_train_np)
    lin = fit_linear(X_train_np, y_train_np)

    rows = [
        {"Model":"Naive",       **score_report(y_test_np, y_pred_naive)},
        {"Model":"DummyMean",   **score_report(y_test_np, dum.predict(X_test_np))},
        {"Model":"Linear",      **score_report(y_test_np, lin.predict(X_test_np))},
    ]

    report = pd.DataFrame(rows).reset_index(drop=True)

    yhat_lin_2024 = float(lin.predict(X_test_np)[0])
    return report, (int(years[test_mask].values[0]), float(y_test_np[0]), yhat_lin_2024)

# -------------------- Prediksi one-step 2025 (Linear) --------------------
def forecast_one_step_2025(df_base, target):
    next_year = int(df_base["Tahun"].max() + 1)
    df_next = pd.concat([df_base.copy(), pd.DataFrame({"Tahun":[next_year]})], ignore_index=True)
    for col in ["Jumlah_ribu","Persen"]:
        if col not in df_next.columns:
            df_next[col] = np.nan

    X_full, y_full, years_full, feats_full = build_features(df_next, target)
    row_mask = (years_full == next_year)
    row_pred = X_full[row_mask]
    fit_mask = ~row_mask
    X_fit_np = X_full[fit_mask].to_numpy()
    y_fit_np = y_full[fit_mask].to_numpy().ravel()

    lin_final = fit_linear(X_fit_np, y_fit_np)
    if row_pred.shape[0] == 0:
        raise RuntimeError("Baris fitur tahun prediksi kosong. Cek konstruksi lag/rolling.")
    row_np = row_pred.to_numpy()
    y_hat = float(lin_final.predict(row_np)[0])

    # Koefisien: bertanda & absolut (diurutkan)
    coef_signed = pd.Series(lin_final.coef_, index=feats_full)
    coef_abs_sorted = coef_signed.abs().sort_values(ascending=False)

    return {
        "year": next_year,
        "y_hat": y_hat,
        "coef_signed": coef_signed,
        "coef_abs_sorted": coef_abs_sorted
    }

# -------------------- Plot helpers --------------------
def plot_actual_vs_pred_2024(year, y_true, y_pred, title, y_label, fname):
    plt.figure(figsize=(6,5))
    plt.bar([f"Aktual {year}", f"Prediksi {year}"], [y_true, y_pred])
    plt.title(title)
    plt.ylabel(y_label)
    for i, v in enumerate([y_true, y_pred]):
        plt.text(i, v, f"{v:.3f}", ha="center", va="bottom")
    plt.tight_layout()
    plt.savefig(OUT / fname, dpi=150)
    maybe_show()

def plot_history_with_forecast(df_hist, fc, ycol, y_label, title, fname):
    plt.figure(figsize=(9,5))
    plt.plot(df_hist["Tahun"], df_hist[ycol], marker="o", label=f"Historis {ycol}")
    if ycol == "Persen":
        yhat = fc["Forecast_Persen"]
    else:
        yhat = fc["Forecast_Jumlah_ribu"]
    plt.plot(fc["Tahun"], yhat, marker="o", linestyle="--", label=f"Forecast {ycol}")
    plt.title(title)
    plt.xlabel("Tahun")
    plt.ylabel(y_label)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT / fname, dpi=150)
    maybe_show()

# --- Tambahan: Visualisasi regresi linear (in-sample) ---
def plot_fitted_vs_actual_timeseries(df_base, target, title, y_label, fname):
    X, y, years, _ = build_features(df_base, target)
    lin = LinearRegression().fit(X.to_numpy(), y.to_numpy().ravel())
    fitted = lin.predict(X.to_numpy())

    plt.figure(figsize=(9,5))
    plt.plot(years, y, marker="o", label="Aktual")
    plt.plot(years, fitted, marker="o", linestyle="--", label="Fitted (Linear)")
    plt.title(title)
    plt.xlabel("Tahun")
    plt.ylabel(y_label)
    plt.grid(True, linestyle="--", alpha=0.4)
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT / fname, dpi=150)
    maybe_show()

def plot_pred_vs_true_scatter(df_base, target, title, fname):
    X, y, years, _ = build_features(df_base, target)
    lin = LinearRegression().fit(X.to_numpy(), y.to_numpy().ravel())
    yhat = lin.predict(X.to_numpy())

    plt.figure(figsize=(6,6))
    plt.scatter(y, yhat)
    mn, mx = float(min(y.min(), yhat.min())), float(max(y.max(), yhat.max()))
    plt.plot([mn, mx], [mn, mx], linestyle="--")
    plt.xlabel("Aktual")
    plt.ylabel("Fitted (Linear)")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(OUT / fname, dpi=150)
    maybe_show()

def plot_residuals_vs_fitted(df_base, target, title, fname):
    X, y, years, _ = build_features(df_base, target)
    lin = LinearRegression().fit(X.to_numpy(), y.to_numpy().ravel())
    fitted = lin.predict(X.to_numpy())
    resid = y.to_numpy().ravel() - fitted

    plt.figure(figsize=(8,5))
    plt.scatter(fitted, resid)
    plt.axhline(0, linestyle="--")
    plt.title(title)
    plt.xlabel("Fitted")
    plt.ylabel("Residual")
    plt.tight_layout()
    plt.savefig(OUT / fname, dpi=150)
    maybe_show()

# -------------------- Util: Tulis & Simpan Koefisien --------------------
def format_and_save_coefs(series_signed, name_prefix):
    # Buat tabel koef bertanda + absolut, diurutkan berdasarkan |koef|
    dfc = pd.DataFrame({"Koefisien": series_signed})
    dfc["|Koef|"] = dfc["Koefisien"].abs()
    dfc = dfc.sort_values("|Koef|", ascending=False)

    # Tampilkan ke console (hingga 6 desimal)
    pd.options.display.float_format = lambda x: f"{x:,.6f}"
    print(f"\n=== KOEFISIEN LINEAR – {name_prefix} (diurutkan |koef|) ===")
    print(dfc.to_string())

    # Simpan ke file
    csv_path = OUT / f"koefisien_{name_prefix.lower().replace(' ', '_')}.csv"
    xlsx_path = OUT / f"koefisien_{name_prefix.lower().replace(' ', '_')}.xlsx"
    dfc.to_csv(csv_path, index=True)
    with pd.ExcelWriter(xlsx_path) as xw:
        dfc.to_excel(xw, sheet_name="Koefisien", index=True)

# -------------------- Main --------------------
if __name__ == "__main__":
    pd.options.display.float_format = lambda x: f"{x:,.3f}"
    df = load_data()
    print(">>> ANALISIS PREDIKTIF KEMISKINAN - Linear Regression (Surakarta) <<<")

    # 1) Evaluasi holdout 2024 (Linear)
    rep_persen, avp_p = evaluate_holdout_2024(df, target="Persen")
    rep_jumlah, avp_j = evaluate_holdout_2024(df, target="Jumlah_ribu")

    print("\n=== HOLDOUT 2024 - Persentase (%) ===")
    print(rep_persen.to_string(index=False))
    print("\n=== HOLDOUT 2024 - Jumlah (ribu jiwa) ===")
    print(rep_jumlah.to_string(index=False))

    # simpan akurasi
    rep_persen.to_csv(OUT/"holdout_persen_2024_linear.csv", index=False)
    rep_jumlah.to_csv(OUT/"holdout_jumlah_2024_linear.csv", index=False)
    with pd.ExcelWriter(OUT/"holdout_all_2024_linear.xlsx") as xw:
        rep_persen.to_excel(xw, sheet_name="Persen", index=False)
        rep_jumlah.to_excel(xw, sheet_name="Jumlah_ribu", index=False)

    # 2) One-step 2025 + koefisien (HANYA 2025)
    f_p = forecast_one_step_2025(df, target="Persen")
    f_j = forecast_one_step_2025(df, target="Jumlah_ribu")

    print(f"\n=== ONE-STEP (2025) ===")
    print(f"Persentase 2025 ≈ {f_p['y_hat']:.3f}")
    # >>> Perubahan di bawah: tampilkan 3 desimal untuk Jumlah_ribu
    print(f"Jumlah_ribu 2025 ≈ {f_j['y_hat']:.3f}")

    # Tulis & simpan koefisien (tanpa grafik)
    format_and_save_coefs(f_p["coef_signed"], "Persentase_2025_one_step")
    format_and_save_coefs(f_j["coef_signed"], "Jumlah_ribu_2025_one_step")

    # Buat dataframe forecast SATU TAHUN (2025) untuk dipakai plotting & ekspor
    fc_2025 = pd.DataFrame([{
        "Tahun": f_p["year"],
        "Forecast_Persen": f_p["y_hat"],
        "Forecast_Jumlah_ribu": f_j["y_hat"]
    }])

    # Simpan hasil forecast
    fc_2025.to_csv(OUT/"forecast_2025_linear.csv", index=False)
    fc_2025.to_excel(OUT/"forecast_2025_linear.xlsx", index=False)

    # -------------------- Plot --------------------
    # Aktual vs prediksi 2024
    year_p, ytrue_p, yhat_p = avp_p
    plot_actual_vs_pred_2024(
        year_p, ytrue_p, yhat_p,
        "Aktual vs Prediksi 2024 - Persentase Kemiskinan (Linear)",
        "Persen (%)",
        "plot_avp_2024_persen_linear.png"
    )
    year_j, ytrue_j, yhat_j = avp_j
    plot_actual_vs_pred_2024(
        year_j, ytrue_j, yhat_j,
        "Aktual vs Prediksi 2024 - Jumlah Penduduk Miskin (Linear)",
        "Ribu jiwa",
        "plot_avp_2024_jumlah_linear.png"
    )

    # Historis + forecast satu titik (2025)
    plot_history_with_forecast(
        df, fc_2025,
        "Persen", "Persen (%)",
        "Historis & Forecast - Persentase Kemiskinan (Linear)",
        "plot_hist_fc_persen_linear.png"
    )
    plot_history_with_forecast(
        df, fc_2025,
        "Jumlah_ribu", "Ribu jiwa",
        "Historis & Forecast - Jumlah Penduduk Miskin (Linear)",
        "plot_hist_fc_jumlah_linear.png"
    )

    print(f"\nFile hasil disimpan di folder: {OUT.resolve()}")

    # --- Tambahan grafik regresi (in-sample) ---
    # 2.1 Garis waktu: Aktual vs Fitted
    plot_fitted_vs_actual_timeseries(
        df, "Persen",
        "Aktual vs Fitted (In-sample) – Persentase Kemiskinan (Linear)",
        "Persen (%)",
        "plot_fitted_actual_persen_linear.png"
    )
    plot_fitted_vs_actual_timeseries(
        df, "Jumlah_ribu",
        "Aktual vs Fitted (In-sample) – Jumlah Penduduk Miskin (Linear)",
        "Ribu jiwa",
        "plot_fitted_actual_jumlah_linear.png"
    )

    # 2.2 Scatter: y_true vs y_pred (garis 45°)
    plot_pred_vs_true_scatter(
        df, "Persen",
        "Scatter Aktual vs Fitted – Persentase (Linear)",
        "plot_scatter_persen_linear.png"
    )
    plot_pred_vs_true_scatter(
        df, "Jumlah_ribu",
        "Scatter Aktual vs Fitted – Jumlah (Linear)",
        "plot_scatter_jumlah_linear.png"
    )

    # 2.3 Diagnostik: Residual vs Fitted
    plot_residuals_vs_fitted(
        df, "Persen",
        "Residual vs Fitted – Persentase (Linear)",
        "plot_resid_persen_linear.png"
    )
    plot_residuals_vs_fitted(
        df, "Jumlah_ribu",
        "Residual vs Fitted – Jumlah (Linear)",
        "plot_resid_jumlah_linear.png"
    )
