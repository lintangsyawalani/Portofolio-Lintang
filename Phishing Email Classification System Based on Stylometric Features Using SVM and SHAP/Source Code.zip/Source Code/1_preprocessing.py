
# Preprocessing 

import pandas as pd  
import re        

# 1. Load Dataset
file_path = "phishing_email.csv"   
df = pd.read_csv(file_path)        

print("=== CEK DATA AWAL ===")
print("Jumlah total data:", len(df))
print("Kolom yang tersedia:", list(df.columns))

print("\nDistribusi Label:")
print(df['label'].value_counts())

print("\nContoh data awal:")
print(df.head(3))


# 2. Fungsi Preprocessing 
def clean_text_stylometric(text):

    text = str(text)

    # Normalisasi line break
    text = text.replace('\r', '\n')

    # Hapus HTML tag
    text = re.sub(r"<.*?>", " ", text)

    # Hapus header email 
    text = re.sub(r"(?i)\bsubject:", " ", text)
    text = re.sub(r"(?i)\bfrom:", " ", text)
    text = re.sub(r"(?i)\bto:", " ", text)

    # Normalisasi whitespace
    text = text.replace('\t', ' ')
    text = re.sub(r"[ ]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)

    text = text.strip()

    return text

if 'text_combined' not in df.columns:
    raise ValueError("Kolom 'text_combined' tidak ditemukan di dataset.")

df["clean_text"] = df["text_combined"].apply(clean_text_stylometric)


print("\n=== CONTOH HASIL PREPROCESSING ===")
print(df[["text_combined", "clean_text"]].head())

# 3. Cek missing value
print("\n=== CEK DATA KOSONG ===")
print(df.isnull().sum())

# 4. Simpan hasil preprocessing
output_path = "phishing_email_cleaned_stylometric.csv"

df.to_csv(output_path, index=False)

print("\n✅ Preprocessing selesai")
print("File disimpan:", output_path)
print("Jumlah data akhir:", len(df))