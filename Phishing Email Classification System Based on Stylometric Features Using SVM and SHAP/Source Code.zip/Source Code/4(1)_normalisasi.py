import joblib
import pandas as pd

# ─────────────────────────────────────────────────────────
# 1. Load Data
# ─────────────────────────────────────────────────────────
df = pd.read_csv("stylometric_features_60.csv")

X     = df.drop("label", axis=1)
label = df["label"]

print(f"✅ Data loaded: {X.shape[0]} baris, {X.shape[1]} fitur")

# ─────────────────────────────────────────────────────────
# 2. Load StandardScaler milik kamu
# ─────────────────────────────────────────────────────────
scaler = joblib.load("scaler_3.pkl")
print(f"✅ Scaler loaded: {type(scaler).__name__}")

# ─────────────────────────────────────────────────────────
# 3. Transform (TIDAK fit ulang — pakai scaler yang sudah ada)
# ─────────────────────────────────────────────────────────
X_scaled = scaler.transform(X)

# ─────────────────────────────────────────────────────────
# 4. Buat DataFrame hasil normalisasi
# ─────────────────────────────────────────────────────────
scaled_df = pd.DataFrame(X_scaled, columns=X.columns)
scaled_df.insert(0, "label", label.values)

# ─────────────────────────────────────────────────────────
# 5. Simpan ke CSV
# ─────────────────────────────────────────────────────────
output_path = "hasil_normalisasi_standardscaler.csv"
scaled_df.to_csv(output_path, index=False)

print(f"\n✅ Hasil normalisasi disimpan ke: {output_path}")
print(f"   Baris  : {scaled_df.shape[0]}")
print(f"   Kolom  : {scaled_df.shape[1]} (termasuk kolom 'label')")

# ─────────────────────────────────────────────────────────
# 6. Preview
# ─────────────────────────────────────────────────────────
print("\n📋 Preview 5 baris pertama:")
print(scaled_df.head().to_string())

# ─────────────────────────────────────────────────────────
# 7. Statistik ringkas
# ─────────────────────────────────────────────────────────
print("\n📊 Statistik hasil normalisasi (tanpa kolom label):")
stats = scaled_df.drop("label", axis=1).describe().T[["mean","std","min","max"]]
stats = stats.round(4)
print(stats.to_string())