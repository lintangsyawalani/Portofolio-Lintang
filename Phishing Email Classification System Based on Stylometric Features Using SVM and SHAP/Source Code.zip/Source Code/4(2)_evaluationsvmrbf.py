# =====================================================
# Evaluation SVM-RBF (Tanpa Training Ulang)
# =====================================================

import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    roc_curve
)

import matplotlib.pyplot as plt
import seaborn as sns

# =====================================================
# 1. Load Dataset
# =====================================================

print("Loading dataset...")

df = pd.read_csv("stylometric_features_60.csv")

X = df.drop("label", axis=1)
y = df["label"]

print("Jumlah data :", df.shape)
print("Jumlah fitur:", X.shape[1])

# =====================================================
# 2. Train-Test Split
# (HARUS sama dengan saat training)
# =====================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("Jumlah data uji:", X_test.shape)

# =====================================================
# 3. Load Scaler
# =====================================================

scaler = joblib.load("scaler_3.pkl")

X_test_scaled = scaler.transform(X_test)

# =====================================================
# 4. Load Model
# =====================================================

model = joblib.load("svm_rbf_model_3.pkl")

print("\nModel berhasil dimuat.")

# =====================================================
# 5. Prediction
# =====================================================

# Prediksi kelas (mekanisme asli SVM)
y_pred = model.predict(X_test_scaled)

# Probabilitas hanya untuk ROC-AUC
y_prob = model.predict_proba(X_test_scaled)[:, 1]

# =====================================================
# 6. Evaluation
# =====================================================

accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)
roc_auc = roc_auc_score(y_test, y_prob)

print("\n========== HASIL EVALUASI ==========")
print(f"Accuracy : {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall   : {recall:.4f}")
print(f"F1 Score : {f1:.4f}")
print(f"ROC AUC  : {roc_auc:.4f}")

# =====================================================
# 7. Save Evaluation
# =====================================================

metrics_df = pd.DataFrame({
    "Metric": [
        "Accuracy",
        "Precision",
        "Recall",
        "F1 Score",
        "ROC AUC"
    ],
    "Value": [
        accuracy,
        precision,
        recall,
        f1,
        roc_auc
    ]
})

metrics_df.to_csv("evaluation_metrics_rbf.csv", index=False)

print("\nEvaluation metrics disimpan ke:")
print("evaluation_metrics_rbf.csv")

# =====================================================
# 8. Confusion Matrix
# =====================================================

cm = confusion_matrix(y_test, y_pred)

print("\nConfusion Matrix")
print(cm)

plt.figure(figsize=(6,5))

sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues"
)

plt.title("Confusion Matrix (SVM-RBF)")
plt.xlabel("Predicted")
plt.ylabel("Actual")

plt.savefig(
    "confusion_matrix_rbf.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

# =====================================================
# 9. ROC Curve
# =====================================================

fpr, tpr, _ = roc_curve(y_test, y_prob)

plt.figure(figsize=(6,5))

plt.plot(
    fpr,
    tpr,
    linewidth=2,
    label=f"AUC = {roc_auc:.3f}"
)

plt.plot([0,1],[0,1],'k--')

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve (SVM-RBF)")
plt.legend(loc="lower right")

plt.savefig(
    "roc_curve_rbf.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()