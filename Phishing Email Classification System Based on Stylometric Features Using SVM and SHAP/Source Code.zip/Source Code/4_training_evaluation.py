
# Training and Evaluation

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    roc_auc_score,
    roc_curve
)

import matplotlib.pyplot as plt
import seaborn as sns
import joblib


# 1. Load Dataset
print("Loading dataset...")
df = pd.read_csv("stylometric_features_60.csv")
print("Jumlah data:", df.shape)

# 2. Split features and labels
X = df.drop("label", axis=1)
y = df["label"]
print("Jumlah fitur:", X.shape[1])

# 3. Train-test split 
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)
print("Train size:", X_train.shape)
print("Test size:", X_test.shape)

# 4. Feature Scaling
scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 5. Hyperparameter Tuning 
print("\nMelakukan GridSearchCV...")

param_grid = {
    "C": [1, 10, 50, 100, 200, 500],
    "gamma": ["scale", 0.1, 0.05, 0.01, 0.005, 0.001],
    "kernel": ["rbf"],
    "class_weight": [None, "balanced"]
}

grid = GridSearchCV(
    SVC(probability=True),
    param_grid,
    cv=5,
    scoring="roc_auc",   
    n_jobs=-1,
    verbose=2
)
print("\nMelakukan training + tuning model...")

grid.fit(X_train_scaled, y_train)

print("\nBest parameters:", grid.best_params_)

model = grid.best_estimator_

# 7. Prediksi (Probabilitas dan label)
y_prob = model.predict_proba(X_test_scaled)[:, 1]

# 8. Threshold Tuning
best_threshold = 0.5
best_f1 = 0

for t in np.arange(0.3, 0.8, 0.05):
    temp_pred = (y_prob >= t).astype(int)
    temp_f1 = f1_score(y_test, temp_pred)

    if temp_f1 > best_f1:
        best_f1 = temp_f1
        best_threshold = t

print("\n===== BEST THRESHOLD =====")
print("Best threshold:", best_threshold)
print("Best F1 Score:", best_f1)

# 9. Evaluation (Default Threshold 0.5)
y_pred_default = (y_prob >= 0.5).astype(int)

accuracy = accuracy_score(y_test, y_pred_default)
precision = precision_score(y_test, y_pred_default)
recall = recall_score(y_test, y_pred_default)
f1 = f1_score(y_test, y_pred_default)
roc_auc = roc_auc_score(y_test, y_prob)

print("\n===== EVALUATION (DEFAULT 0.5) =====")
print("Accuracy :", accuracy)
print("Precision:", precision)
print("Recall   :", recall)
print("F1 Score :", f1)
print("ROC AUC  :", roc_auc)

# 10. Evaluation (Best Threshold)
y_pred_opt = (y_prob >= best_threshold).astype(int)

accuracy_opt = accuracy_score(y_test, y_pred_opt)
precision_opt = precision_score(y_test, y_pred_opt)
recall_opt = recall_score(y_test, y_pred_opt)
f1_opt = f1_score(y_test, y_pred_opt)

print("\n===== EVALUATION (OPTIMIZED) =====")
print("Accuracy :", accuracy_opt)
print("Precision:", precision_opt)
print("Recall   :", recall_opt)
print("F1 Score :", f1_opt)

# 11. Save Best Threshold
with open("best_threshold.txt", "w") as f:
    f.write(str(best_threshold))

print("\nThreshold disimpan ke: best_threshold.txt")

# 12. Save Evaluation Metrics to CSV
metrics_df = pd.DataFrame({
    "Metric": ["Accuracy", "Precision", "Recall", "F1 Score", "ROC AUC"],
    "Default": [accuracy, precision, recall, f1, roc_auc],
    "Optimized": [accuracy_opt, precision_opt, recall_opt, f1_opt, roc_auc]
})

metrics_df.to_csv("evaluation_metrics_3.csv", index=False)

print("\nMetrics disimpan ke: evaluation_metrics_3.csv")

# 13. Confusion Matrix (Best Threshold)
cm = confusion_matrix(y_test, y_pred_opt)

print("\nConfusion Matrix:")
print(cm)

plt.figure(figsize=(6,5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")

plt.title("Confusion Matrix (Optimized)")
plt.xlabel("Predicted")
plt.ylabel("Actual")

plt.savefig("confusion_matrix_3.png", dpi=300, bbox_inches="tight")

plt.show()

# 14. ROC CURVE
fpr, tpr, _ = roc_curve(y_test, y_prob)

plt.figure(figsize=(6,5))

plt.plot(fpr, tpr, label="ROC Curve (AUC = %.3f)" % roc_auc)
plt.plot([0,1], [0,1], linestyle="--")

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")

plt.legend()

plt.savefig("roc_curve_3.png", dpi=300, bbox_inches="tight")

plt.show()

# 15. Save Model and Scaler
joblib.dump(model, "svm_rbf_model_3.pkl")
joblib.dump(scaler, "scaler_3.pkl")

print("\nModel berhasil disimpan:")
print("svm_rbf_model_3.pkl")
print("scaler_3.pkl")