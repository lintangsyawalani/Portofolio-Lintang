
# Full Inference and Sample XAI

import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import joblib

from sklearn.metrics import confusion_matrix, classification_report

FEATURES_CSV = "stylometric_features_60.csv"

MODEL_PKL    = "svm_rbf_model_3.pkl"
SCALER_PKL   = "scaler_3.pkl"

OUT_CSV      = "svm_predictions_full.csv"
DIST_PNG     = "prediction_distribution.png"
CM_PNG       = "confusion_matrix_full.png"
XAI_CSV      = "xai_samples.csv"

# 1. Load Threshold
with open("best_threshold.txt", "r") as f:
    THRESHOLD = float(f.read())

print(f"Threshold digunakan: {THRESHOLD}")

# 2. Load Dataset
print("\nLoading dataset...")

df = pd.read_csv(FEATURES_CSV)
print("Jumlah data:", len(df))

if "label" in df.columns:
    y = df["label"].astype(int)
    X = df.drop(columns=["label"])
    print("[INFO] Label ditemukan → akan hitung evaluasi")
else:
    y = None
    X = df.copy()
    print("[INFO] Tidak ada label → hanya prediksi")

feature_names = list(X.columns)
print("Jumlah fitur:", len(feature_names))

# 3. Load Model and Scaler
print("\nLoading model...")

model = joblib.load(MODEL_PKL)
scaler = joblib.load(SCALER_PKL)

print("Model dan scaler berhasil dimuat")

# 4. Feature Scaling
print("\n=== CEK FITUR (SEBELUM SCALING) ===")
print(X.head(5))   
X_scaled = scaler.transform(X)
print("\n=== CEK FITUR (SETELAH SCALING) ===")
print(X_scaled[:5]) 

# 5. Prediction
print("\nMelakukan prediksi...")

y_prob = model.predict_proba(X_scaled)[:, 1]

print("\n=== CEK PROBABILITAS ===")
print(y_prob[:10])

y_pred = (y_prob >= THRESHOLD).astype(int)

pred_str = np.where(y_pred == 1, "Phishing", "Legitimate")

# 6. Save Results
result = pd.DataFrame({
    "row_id": np.arange(1, len(df)+1),
    "predicted_label": y_pred,
    "predicted_label_str": pred_str,
    "predicted_proba_phishing": np.round(y_prob, 6),
    "threshold": THRESHOLD
})

if y is not None:
    result["true_label"] = y
    result["status"] = np.where(y_pred == y, "Benar", "Salah")

result.to_csv(OUT_CSV, index=False)

print(f"\nHasil prediksi disimpan ke: {OUT_CSV}")

# 7. Distribution Plot
print("\nDistribusi prediksi:")
print(result["predicted_label_str"].value_counts())

plt.figure(figsize=(6,4))
sns.countplot(x=result["predicted_label_str"])

plt.title("Distribusi Prediksi")
plt.xlabel("Kelas")
plt.ylabel("Jumlah")

plt.tight_layout()
plt.savefig(DIST_PNG, dpi=300)
plt.close()

print(f"Gambar distribusi disimpan: {DIST_PNG}")

# 8. Confusion Matrix
if y is not None:

    cm = confusion_matrix(y, y_pred)

    print("\nConfusion Matrix:")
    print(cm)

    print("\nClassification Report:")
    print(classification_report(y, y_pred))

    plt.figure(figsize=(6,5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Legitimate","Phishing"],
                yticklabels=["Legitimate","Phishing"])

    plt.title("Confusion Matrix (Full Inference)")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")

    plt.tight_layout()
    plt.savefig(CM_PNG, dpi=300)
    plt.close()

    print(f"Confusion matrix disimpan: {CM_PNG}")

# 9. Ambil Sampel untuk XAI
if y is not None:

    print("\nMengambil sampel untuk XAI...")

    df_xai = result.copy()
    df_xai["dist_to_threshold"] = np.abs(
        df_xai["predicted_proba_phishing"] - THRESHOLD
    )

    samples = []

    def ambil(df_sub, n, label):
        if len(df_sub) > 0:
            s = df_sub.head(n).copy()
            s["xai_category"] = label
            samples.append(s)

    # TP, TN, FP, FN
    tp = df_xai[(df_xai["true_label"] == 1) & (df_xai["predicted_label"] == 1)]
    tn = df_xai[(df_xai["true_label"] == 0) & (df_xai["predicted_label"] == 0)]
    fp = df_xai[(df_xai["true_label"] == 0) & (df_xai["predicted_label"] == 1)]
    fn = df_xai[(df_xai["true_label"] == 1) & (df_xai["predicted_label"] == 0)]

    ambil(tp.sort_values("predicted_proba_phishing", ascending=False), 3, "TP")
    ambil(tn.sort_values("predicted_proba_phishing", ascending=True), 3, "TN")
    ambil(fp.sort_values("predicted_proba_phishing", ascending=False), 2, "FP")
    ambil(fn.sort_values("predicted_proba_phishing", ascending=True), 2, "FN")

    # Borderline
    borderline = df_xai[df_xai["dist_to_threshold"] <= 0.03]
    ambil(borderline.sort_values("dist_to_threshold"), 2, "BORDERLINE")

    if len(samples) > 0:
        xai_samples = pd.concat(samples, ignore_index=True)
        xai_samples.to_csv(XAI_CSV, index=False)

        print(f"Sampel XAI disimpan: {XAI_CSV}")
        print("\nJumlah per kategori:")
        print(xai_samples["xai_category"].value_counts())
    else:
        print("Tidak ada sampel XAI ditemukan")

print("\n=== FULL INFERENCE SELESAI ===")