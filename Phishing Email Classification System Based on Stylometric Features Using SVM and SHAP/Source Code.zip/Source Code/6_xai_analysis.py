
# Explainable AI SHAP

import os
import numpy as np
import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt

FEATURES_CSV    = "stylometric_features_60.csv"

MODEL_PKL       = "svm_rbf_model_3.pkl"
SCALER_PKL      = "scaler_3.pkl"

XAI_SAMPLES_CSV = "xai_samples.csv"

OUT_DIR = "xai_outputs"
os.makedirs(OUT_DIR, exist_ok=True)

# 1. Load Dataset
print("Loading data...")

df = pd.read_csv(FEATURES_CSV)

y = df["label"].astype(int)
X = df.drop(columns=["label"])

feature_names = list(X.columns)

print("Jumlah data:", len(X))
print("Jumlah fitur:", len(feature_names))

# 2. Load Model and Scaler
print("\nLoading model...")

model  = joblib.load(MODEL_PKL)
scaler = joblib.load(SCALER_PKL)

X_scaled = scaler.transform(X)

# 3. Load XAI Samples
print("\nLoading XAI samples...")

xai_samples = pd.read_csv(XAI_SAMPLES_CSV)

print(xai_samples["xai_category"].value_counts())

sample_indices = (xai_samples["row_id"] - 1).astype(int).tolist()

X_samples = X.iloc[sample_indices]
X_samples_scaled = X_scaled[sample_indices]

# 4. SHAP Global Explanation
print("\nMenjalankan SHAP Global...")

bg_size = min(300, X_scaled.shape[0])
bg_idx = np.random.choice(X_scaled.shape[0], bg_size, replace=False)
X_bg = X_scaled[bg_idx]

explainer = shap.KernelExplainer(model.predict_proba, X_bg)

# BASE VALUE
if isinstance(explainer.expected_value, (list, np.ndarray)):
    base_val = explainer.expected_value[1]
else:
    base_val = explainer.expected_value

print(f"\nBase value (kelas phishing): {base_val:.4f}")

# SHAP VALUES GLOBAL
shap_values = explainer.shap_values(X_bg, nsamples=500)

if isinstance(shap_values, list):
    shap_values_pos = shap_values[1]
else:
    if len(shap_values.shape) == 3:
        shap_values_pos = shap_values[:, :, 1]
    else:
        shap_values_pos = shap_values

# SHAP BAR
plt.figure()
shap.summary_plot(
    shap_values_pos,
    X_bg,
    feature_names=feature_names,
    plot_type="bar",
    show=False
)
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "shap_summary_bar.png"), dpi=300)
plt.close()

print("SHAP summary bar disimpan")

# SHAP BEESWARM
plt.figure()
shap.summary_plot(
    shap_values_pos,
    X_bg,
    feature_names=feature_names,
    show=False
)
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "shap_beeswarm.png"), dpi=300)
plt.close()

print("SHAP beeswarm disimpan")

# 5. Global Feature Importance Ranking
print("\nMenyimpan ranking feature importance...")

mean_abs_shap = np.abs(shap_values_pos).mean(axis=0)

importance_df = pd.DataFrame({
    "Feature": feature_names,
    "Mean_SHAP_Importance": mean_abs_shap
})

importance_df = importance_df.sort_values(
    by="Mean_SHAP_Importance",
    ascending=False
)

importance_df.to_csv(
    os.path.join(
        OUT_DIR,
        "shap_feature_importance_ranking.csv"
    ),
    index=False
)

print("\nTop 10 fitur paling berpengaruh:")
print(
    importance_df.head(10)
)

print("Feature importance ranking disimpan")

# 6. SHAP Local Explanation
print("\nSHAP Local Explanation...")

shap_values_samples = explainer.shap_values(X_samples_scaled, nsamples=500)

if isinstance(shap_values_samples, list):
    shap_samples_pos = shap_values_samples[1]
else:
    if len(shap_values_samples.shape) == 3:
        shap_samples_pos = shap_values_samples[:, :, 1]
    else:
        shap_samples_pos = shap_values_samples

for i in range(len(X_samples_scaled)):

    rid  = xai_samples.iloc[i]["row_id"]
    cat  = xai_samples.iloc[i]["xai_category"]

    print(f"SHAP row {rid} ({cat})")

    shap_row = shap_samples_pos[i]

    exp = shap.Explanation(
        values=shap_row,
        base_values=base_val,
        data=X_samples_scaled[i],
        feature_names=feature_names
    )

    plt.figure(figsize=(8,6))
    shap.plots.waterfall(exp, max_display=10, show=False)

    fname = f"shap_waterfall_row{rid}.png"
    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, fname), dpi=300)
    plt.close()

print("SHAP local selesai")

print("\n=== XAI SELESAI ===")
print("Hasil ada di folder:", OUT_DIR)