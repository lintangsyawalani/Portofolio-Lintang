
# Gmail System

import os
import base64
import numpy as np
import pandas as pd
import joblib
import shap
import re

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]

MODEL_PKL  = "svm_rbf_model_3.pkl"
SCALER_PKL = "scaler_3.pkl"
FEATURE_CSV = "stylometric_features_60.csv"

# 1. Load Threshold
with open("best_threshold.txt", "r") as f:
    THRESHOLD = float(f.read())

print("Threshold digunakan:", THRESHOLD)

# 2. Preprocessing
def clean_text_stylometric(text):

    text = str(text)

    text = text.replace('\r', '\n')
    text = re.sub(r"<.*?>", " ", text)

    text = re.sub(r"(?i)\bsubject:", " ", text)
    text = re.sub(r"(?i)\bfrom:", " ", text)
    text = re.sub(r"(?i)\bto:", " ", text)

    text = text.replace('\t', ' ')
    text = re.sub(r"[ ]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()

# 3. Feature Extraction
from feature_extraction import extract_60_features

train_df = pd.read_csv("stylometric_features_60.csv")

feature_names = list(
    train_df.drop(columns=["label"]).columns
)

# 4. Load Model and Scaler
def load_model():
    model  = joblib.load(MODEL_PKL)
    scaler = joblib.load(SCALER_PKL)
    return model, scaler

# 5. SHAP Explainer
def build_shap_explainer(model, scaler):

    print("Membangun SHAP explainer...")

    df_bg = pd.read_csv(FEATURE_CSV)

    if "label" in df_bg.columns:
        X_bg = df_bg.drop(columns=["label"])
    else:
        X_bg = df_bg.copy()

    bg_size = min(100, len(X_bg))
    X_bg_sample = X_bg.sample(
        n=bg_size,
        random_state=42
    )

    X_bg_scaled = scaler.transform(X_bg_sample)

    explainer = shap.KernelExplainer(model.predict_proba, X_bg_scaled)

    return explainer

# 6. Gmail API
def get_gmail_service():

    creds = None

    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                "credentials.json", SCOPES
            )
            creds = flow.run_local_server(port=0)

        with open("token.json", "w") as token:
            token.write(creds.to_json())

    return build("gmail", "v1", credentials=creds)

def get_latest_emails(service, max_results=5):

    results = service.users().messages().list(
        userId="me",
        labelIds=["INBOX"],
        maxResults=max_results
    ).execute()

    messages = results.get("messages", [])
    emails = []

    for m in messages:

        msg = service.users().messages().get(
            userId="me",
            id=m["id"],
            format="full"
        ).execute()

        headers = msg["payload"].get("headers", [])

        subject = ""
        for h in headers:
            if h["name"].lower() == "subject":
                subject = h["value"]

        body = ""

        if "data" in msg["payload"]["body"]:
            data = msg["payload"]["body"]["data"]
            body = base64.urlsafe_b64decode(data).decode("utf-8", errors="ignore")
        else:
            parts = msg["payload"].get("parts", [])
            for part in parts:
                if part.get("mimeType") == "text/plain":
                    data = part["body"].get("data")
                    if data:
                        body = base64.urlsafe_b64decode(data).decode("utf-8", errors="ignore")
                        break

        full_text = f"Subject: {subject}\n\n{body}"

        emails.append({
            "subject": subject,
            "body": body,
            "full_text": full_text
        })

    return emails

# 7. Predict and XAI
def classify_and_explain(email_text, model, scaler, explainer):

    cleaned = clean_text_stylometric(email_text)

    feat_list = extract_60_features(cleaned)
    feat_df = pd.DataFrame([feat_list], columns=feature_names)
    print("\nKolom feat_df:")
    print(
    feat_df.columns.tolist()[:20]
    )

    print("\nfeature_names:")
    print(
    feature_names[:20]
    )

    print("\n20 nilai pertama feat_list:")
    print(
    feat_list[:20]
    )
    X_scaled = scaler.transform(feat_df)

    X_scaled = np.clip(
            X_scaled,
            -3,
            3
    )

    # Prediksi Menggunakan Decision Function
    print("\nRAW FEATURES")
    print(feat_df.iloc[0,:10])

    print("\nSCALED FEATURES")
    print(X_scaled[0,:10])
    score = model.decision_function(X_scaled)[0]

    print("Decision score:", score)

    proba = 1/(1+np.exp(-score))

    if proba >= THRESHOLD:
        label_str="Phishing"
    else:
        label_str="Legitimate"

    # SHAP
    shap_values = explainer.shap_values(
        X_scaled,
        nsamples=500 
    )

    if isinstance(shap_values, list):
        shap_ph = shap_values[1][0]
    else:
        if shap_values.ndim == 3:
            shap_ph = shap_values[0,:,1]
        else:
            shap_ph = shap_values[0]

    s = pd.Series(shap_ph,index=feat_df.columns)

    top_features = (
        s.abs()
         .sort_values(ascending=False)
         .head(5)
         .index
    )
    explanation=[]
    for f in top_features:
        val=s[f]
        if val>0:
            explanation.append(
                f"- {f} mendorong ke phishing ({val:.4f})"
            )

        else:
            explanation.append(
                f"- {f} mengarah ke legitimate ({val:.4f})"
            )

    return label_str, proba, explanation

# 8. Main Program
if __name__ == "__main__":

    print("===================================")
    print("   PHISHING CLASSIFICATION SYSTEM")
    print("===================================")

    print("1. Gmail")
    print("2. Manual")

    mode = input("Pilih mode: ").strip()

    print("\nLoading model...")
    model, scaler = load_model()

    print(model)

    explainer = build_shap_explainer(model, scaler)

    # Mode Gmail
    if mode == "1":

        print("\nMenghubungkan ke Gmail...")
        service = get_gmail_service()

        emails = get_latest_emails(service, max_results=5)

        print("\n===== HASIL =====\n")

        for i, e in enumerate(emails, 1):

            print(f"[Email {i}]")
            print("Subject :", e["subject"])
            print("Preview :", e["body"][:120].replace("\n", " "), "...")

            label, proba, explanation = classify_and_explain(
                e["full_text"], model, scaler, explainer
            )

            print(f"PREDIKSI: {label} (prob = {proba:.3f})")

            print("Penjelasan:")
            for line in explanation:
                print(line)

            print("-" * 70)

    # Mode Input Manual
    else:

        print("\nMasukkan email (akhiri ===END===):")

        lines = []
        while True:
            line = input()
            if line.strip() == "===END===":
                break
            lines.append(line)

        email_text = "\n".join(lines)

        label, proba, explanation = classify_and_explain(
            email_text, model, scaler, explainer
        )

        print("\n===== HASIL =====")
        print(f"PREDIKSI: {label} (prob = {proba:.3f})")

        print("Penjelasan:")
        for line in explanation:
            print(line)

        print("-" * 70)