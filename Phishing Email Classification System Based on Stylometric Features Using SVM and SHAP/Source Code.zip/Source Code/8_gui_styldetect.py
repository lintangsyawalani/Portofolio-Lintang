# ============================================================
# Aplikasi Berbasis Web Streamlit
# ============================================================

import os
import base64
import re
from statistics import pstdev
from collections import Counter

import streamlit as st
import numpy as np
import pandas as pd
import joblib
import shap
import textstat
import nltk

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize

# IMPORT LIB GMAIL
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

# ============================================================
# SETUP HALAMAN & THEME BIRU MUDA
# ============================================================
st.set_page_config(page_title="StylDetect GUI", layout="wide", page_icon="📧")

st.markdown(
    """
    <style>
    /* Background utama */
    [data-testid="stAppViewContainer"] {
        background: linear-gradient(135deg, #b3d9ff, #e6f2ff, #cce6ff);
        color: #0d2b4d;
    }

    /* Sidebar */
    [data-testid="stSidebar"] {
        background-color: #b3d9ff !important;
    }
    [data-testid="stSidebar"] * {
        color: #0d2b4d !important;
    }

    /* Label input */
    .stRadio > label, .stSlider > label, .stTextArea > label {
        color: #0d2b4d !important;
        font-weight: 600 !important;
    }

    /* Text area */
    textarea, .stTextArea textarea {
        background-color: #f2f8ff !important;
        color: #0d2b4d !important;
        border-radius: 0.7rem !important;
        border: 1px solid #89bde6 !important;
        padding: 0.7rem !important;
    }

    /* Tombol */
    .stButton>button {
        background: linear-gradient(135deg, #5aa4f7, #338bff);
        color: white !important;
        border-radius: 999px;
        padding: 0.55rem 1.4rem;
        border: none;
        font-weight: 600;
        font-size: 0.95rem;
        box-shadow: 0px 6px 20px rgba(51, 139, 255, 0.45);
    }
    .stButton>button:hover {
        background: linear-gradient(135deg, #3c7bd9, #1a6feb);
        box-shadow: 0px 8px 28px rgba(51, 139, 255, 0.65);
    }

    /* Expander header */
    .streamlit-expanderHeader {
        font-weight: 600 !important;
        color: #0d2b4d !important;
    }

    </style>
    """,
    unsafe_allow_html=True,
)

# ============================================================
# 1. SETUP NLTK
# ============================================================

for pkg in ["punkt", "stopwords", "punkt_tab"]:
    try:
        nltk.data.find(f"tokenizers/{pkg}")
    except:
        nltk.download(pkg, quiet=True)

# ============================================================
# 2. KONFIGURASI FILE MODEL & SCALER
# ============================================================

MODEL_PKL  = "svm_rbf_model_3.pkl"
SCALER_PKL = "scaler_3.pkl"
FEATURE_CSV = "stylometric_features_60.csv"

# Gmail scope
SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]

with open("best_threshold.txt", "r") as f:
    THRESHOLD = float(f.read())

# ============================================================
# 3. PREPROCESSING
# ============================================================

def clean_text_stylometric(text: str) -> str:
    text = str(text)

    # normalisasi line break
    text = text.replace('\r', '\n')

    # hapus tag HTML
    text = re.sub(r"<.*?>", " ", text)

    # hapus header Subject/From/To
    text = re.sub(r"(?i)\bsubject:", " ", text)
    text = re.sub(r"(?i)\bfrom:", " ", text)
    text = re.sub(r"(?i)\bto:", " ", text)

    # normalisasi whitespace
    text = text.replace('\t', ' ')
    text = re.sub(r"[ ]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)

    return text.strip()

# ============================================================
# 4. FUNGSI EKSTRAKSI 60 FITUR
# ============================================================

from feature_extraction import extract_60_features

train_df = pd.read_csv("stylometric_features_60.csv")

feature_names = list(
    train_df.drop(columns=["label"]).columns
)
print(len(feature_names))
print(feature_names[:10])

# ============================================================
# 5. CACHE MODEL, SCALER, SHAP EXPLAINER
# ============================================================

@st.cache_resource
def load_model_and_scaler():
    model  = joblib.load(MODEL_PKL)
    scaler = joblib.load(SCALER_PKL)
    return model, scaler

@st.cache_resource
def get_shap_explainer(_model, _scaler):

    df_bg = pd.read_csv(FEATURE_CSV)

    if "label" in df_bg.columns:
        X_bg = df_bg.drop(columns=["label"])
    else:
        X_bg = df_bg.copy()

    X_bg_sample = X_bg.sample(100, random_state=42)
    X_bg_scaled = _scaler.transform(X_bg_sample.values)

    explainer = shap.KernelExplainer(_model.predict_proba, X_bg_scaled)

    return explainer

# ============================================================
# 6. GMAIL: SERVICE + AMBIL EMAIL
# ============================================================

@st.cache_resource
def get_gmail_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    service = build("gmail", "v1", credentials=creds)
    return service

def _get_body_from_message(msg):
    """Ambil teks utama dari message Gmail."""
    def walk_parts(part):
        mime_type = part.get("mimeType", "")
        if mime_type == "text/plain" and "data" in part.get("body", {}):
            data = part["body"]["data"]
            return base64.urlsafe_b64decode(data).decode("utf-8", errors="ignore")
        for sub in part.get("parts", []) or []:
            text = walk_parts(sub)
            if text:
                return text
        return ""
    payload = msg.get("payload", {})
    text = walk_parts(payload)
    if not text:
        text = msg.get("snippet", "")
    return text

def fetch_recent_emails(service, max_results=5):
    results = service.users().messages().list(
        userId="me",
        labelIds=["INBOX"],
        maxResults=max_results
    ).execute()
    messages = results.get("messages", [])
    emails = []
    for m in messages:
        msg = service.users().messages().get(userId="me", id=m["id"], format="full").execute()
        headers = msg.get("payload", {}).get("headers", [])
        subject = ""
        sender  = ""
        for h in headers:
            if h["name"].lower() == "subject":
                subject = h["value"]
            if h["name"].lower() == "from":
                sender = h["value"]
        body = _get_body_from_message(msg)
        emails.append({
            "subject": subject,
            "from": sender,
            "body": body
        })
    return emails

# ============================================================
# 7. FUNGSI KLASIFIKASI + XAI UNTUK 1 EMAIL
# ============================================================

def classify_and_explain(email_text, model, scaler, explainer, topk=5):
    cleaned = clean_text_stylometric(email_text.lower())
    feat_list = extract_60_features(cleaned)
    feat_df   = pd.DataFrame([feat_list], columns=feature_names)
    feat_df = feat_df.reindex(columns=feature_names)


    X_scaled = scaler.transform(feat_df)
    X_scaled = np.clip(X_scaled, -3,3)
    
    proba = model.predict_proba(X_scaled)[0][1]
    
    if proba >= THRESHOLD:
        label_str = "Phishing"
    else:
        label_str = "Legitimate"

    shap_values = explainer.shap_values(X_scaled, nsamples=300)

    if isinstance(shap_values, list):
        shap_ph = shap_values[1][0]
    else:
        if shap_values.ndim == 3:
            shap_ph = shap_values[0, :, 1]
        else:
            shap_ph = shap_values[0]

    s = pd.Series(shap_ph, index=feature_names)
    top_features = s.abs().sort_values(ascending=False).head(topk).index
    
    explanation_rows = []

    for fname in top_features:
        val = s[fname]
        if val > 0:
            arah = "mendorong ke phishing"
        else:
            arah = "menguatkan legitimate"
        explanation_rows.append({
            "Fitur": fname,
            "Nilai SHAP": f"{val:.4f}",
            "Arah": arah
        })
    explanation_df = pd.DataFrame(explanation_rows)

    return label_str, float(proba), explanation_df

# ============================================================
# 8. STREAMLIT UI
# ============================================================

st.title("📧 Sistem Klasifikasi Email Phishing")
st.write("Berbasis **fitur stylometric** dan **Explainable Artificial Intelligence (SHAP)**.")
st.markdown("---")

# Pilih sumber email
mode = st.radio(
    "Pilih sumber email:",
    ("Masukkan email manual", "Ambil dari Gmail")
)

model, scaler = load_model_and_scaler()
explainer = get_shap_explainer(model, scaler)

# -------------------- MODE 1: MANUAL ------------------------
if mode == "Masukkan email manual":
    st.subheader("1️⃣ Masukkan isi email")

    default_text = """Hi,

Your account will be blocked in 24 hours. Please click the link below to verify your identity immediately.

Best regards,
Support Team
"""
    email_input = st.text_area(
        "Tempel isi email di sini (bahasa Inggris dianjurkan):",
        value=default_text,
        height=250
    )

    topk = st.slider("Jumlah fitur penting yang ditampilkan (SHAP)", 3, 15, 5)

    if st.button("🔍 Klasifikasi Email (Manual)"):
        if not email_input.strip():
            st.warning("Silakan isi teks email terlebih dahulu.")
        else:
            with st.spinner("Memproses email..."):
                label_str, proba, explanation_df = classify_and_explain(
                    email_input, model, scaler, explainer, topk=topk
                )

            st.markdown("### 2️⃣ Hasil Klasifikasi")
            if label_str == "Phishing":
                st.error(f"🚨 Prediksi: **{label_str}** (probabilitas phishing = {proba:.3f})")
            else:
                st.success(f"✅ Prediksi: **{label_str}** (probabilitas phishing = {proba:.3f})")

            st.markdown("### 3️⃣ Penjelasan (XAI — Fitur Paling Berpengaruh)")
            st.write(
                "Tabel di bawah menunjukkan fitur stylometric dengan kontribusi (nilai SHAP) "
                "paling besar terhadap keputusan model untuk kelas *phishing*."
            )
            st.dataframe(explanation_df, use_container_width=True)

            st.markdown(
                "> Nilai SHAP positif berarti fitur tersebut **mendorong model ke arah phishing**, "
                "sedangkan nilai SHAP negatif berarti fitur tersebut **lebih menguatkan kelas legitimate**."
            )

# -------------------- MODE 2: GMAIL -------------------------
else:
    st.subheader("1️⃣ Ambil email dari Gmail")

    num_email = st.slider("Jumlah email terbaru yang dianalisis", 1, 10, 5)

    if st.button("📥 Hubungkan & Klasifikasikan Email Gmail"):
        with st.spinner("Menghubungkan ke Gmail & mengambil email..."):
            service = get_gmail_service()
            emails = fetch_recent_emails(service, max_results=num_email)

        if not emails:
            st.warning("Tidak ada email yang ditemukan di inbox.")
        else:
            st.markdown("### 2️⃣ Hasil Klasifikasi Email Gmail")
            for i, em in enumerate(emails, start=1):
                label_str, proba, explanation_df = classify_and_explain(
                    em["body"], model, scaler, explainer, topk=5
                )

                summary = f"{i}. {em['subject'] or '(tanpa subjek)'}"
                with st.expander(summary, expanded=False):
                    st.markdown(f"**From:** {em['from']}")
                    st.markdown(f"**Subject:** {em['subject']}")
                    if label_str == "Phishing":
                        st.error(f"🚨 Prediksi: **{label_str}** (probabilitas phishing = {proba:.3f})")
                    else:
                        st.success(f"✅ Prediksi: **{label_str}** (probabilitas phishing = {proba:.3f})")

                    st.markdown("**Fitur paling berpengaruh (SHAP):**")
                    st.dataframe(explanation_df, use_container_width=True)

            st.markdown(
                "> Analisis di atas dilakukan langsung dari isi email Gmail (body), "
                "yang sudah diproses dengan fungsi preprocessing dan fitur stylometric yang sama seperti saat training."
            )
