
# Stylometric Feature Extraction

import pandas as pd
import numpy as np
import textstat
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from sklearn.feature_extraction.text import CountVectorizer
nltk.download('punkt')

# Word Lists
PRONOUNS = ["i","you","he","she","it","we","they","me","him","her","us","them","my","your","his","their","our"]

FIRST_PERSON = ["i","we"]
SECOND_PERSON = ["you"]

PREPOSITIONS = ["in","on","at","by","with","from","to","for","of","about","into","over","after"]
FUNCTION_WORDS = ["the","is","at","which","on","a","an","and","or","but","if","then","because"]

IMPERATIVE = ["click","verify","submit","download","update","confirm","login","sign","reset","open","view","check","validate","access","review","complete","fill","enter","reply","respond"]
MODAL = ["can","could","should","must","will","would","may","might"]
UNCERTAINTY = ["maybe","possibly","perhaps","likely","unlikely","apparently"]

TECHNICAL = ["security","account","update","technical","password","login","authentication","verification","server","system","access","credential","user","database"]
PROMOTIONAL = ["offer","deal","free","bonus","reward","discount","win","gift","promotion","limited","exclusive"]

POLITE = ["please","thank","thanks","appreciate","kindly","regards","sincerely"]
AGGRESSIVE = ["must","now","immediately","required","urgent","action","important","attention","warning"]
URGENCY = ["urgent","asap","immediately","now","today","instantly","quickly","deadline","expire","expiring","limited","soon"]

CONDITIONAL = ["if","unless","otherwise","in case"]
PERSONALIZATION = ["you","your","yours","user","customer","client"]

CONJUNCTIONS = ["and","but","or","because","so","although","however","therefore"]

PUNCT = [".",",","!",":","-","\"","(",")","/","\\"]

# 60 Features
feature_names = [

# Lexical (11)
"word_count","char_count","avg_word_length","sentence_count",
"avg_sentence_length","unique_word_count","lexical_diversity",
"email_symbol_count","uppercase_word_count","uppercase_word_ratio",
"complex_words_count",

# Syntactic (11)
"comma_count","semicolon_count","colon_count","exclamation_count",
"quotation_count","dash_count","sentence_complexity_ratio",
"clause_density","pronoun_density","preposition_density",
"function_word_density",

# Punctuation (11)
"dot_frequency","comma_frequency","exclamation_frequency",
"colon_frequency","dash_frequency","quote_frequency",
"open_parenthesis_frequency","close_parenthesis_frequency",
"slash_frequency","backslash_frequency","punctuation_variety",

# Readability (5)
"flesch_reading_ease","smog_index","dale_chall_score",
"coleman_liau_index","gunning_fog_index",

# Word Category (7)
"first_person_pronouns","second_person_pronouns",
"imperative_verbs_count","modal_verbs_count",
"uncertainty_adverbs_count","technical_jargon_count",
"promotional_words_count",

# Email Specific (3)
"email_count","uppercase_ratio_email","attachment_mentions",

# Complexity (3)
"bigram_count","trigram_count","word_length_variation",

# Stylistic (9)
"politeness_markers","aggressiveness_markers","urgency_markers",
"conditional_phrases","personalization_markers",
"pronoun_count","conjunction_count","stopword_ratio",
"avg_syllables_per_word"

]

def tokenize(text):

    words = word_tokenize(text)
    sentences = sent_tokenize(text)

    return words, sentences

# Feature Extraction Function
def extract_60_features(text):

    text = str(text)

    words, sentences = tokenize(text)
    words_lower = [w.lower() for w in words]

    word_count = len(words)
    char_count = len(text)
    sentence_count = len(sentences)

    if word_count == 0:
        word_count = 1

    if sentence_count == 0:
        sentence_count = 1

    # Lexical
    unique_word_count = len(set(words_lower))
    avg_word_length = np.mean([len(w) for w in words]) if words else 0
    avg_sentence_length = word_count / sentence_count
    lexical_diversity = unique_word_count / word_count

    email_symbol_count = text.count("@")

    uppercase_words = [w for w in words if w.isupper()]
    uppercase_word_count = len(uppercase_words)
    uppercase_word_ratio = uppercase_word_count / word_count

    complex_words_count = sum(1 for w in words if len(w) > 6)

    # Syntactic
    comma_count = text.count(",")
    semicolon_count = text.count(";")
    colon_count = text.count(":")

    exclamation_count = text.count("!")
    quotation_count = text.count('"')
    dash_count = text.count("-")

    sentence_complexity_ratio = sum(words_lower.count(c) for c in CONJUNCTIONS) / sentence_count
    clause_density = sum(words_lower.count(c) for c in CONJUNCTIONS) / sentence_count

    pronoun_density = sum(words_lower.count(p) for p in PRONOUNS) / word_count
    preposition_density = sum(words_lower.count(p) for p in PREPOSITIONS) / word_count
    function_word_density = sum(words_lower.count(p) for p in FUNCTION_WORDS) / word_count

    # Punctuation
    punctuation_freq = []

    for p in PUNCT:
        punctuation_freq.append(text.count(p) / char_count if char_count else 0)

    punctuation_variety = sum(1 for p in PUNCT if text.count(p) > 0)

    # Readability
    flesch = textstat.flesch_reading_ease(text)
    smog = textstat.smog_index(text)
    dale = textstat.dale_chall_readability_score(text)
    coleman = textstat.coleman_liau_index(text)
    gunning = textstat.gunning_fog(text)

    # Word category
    first_person = sum(words_lower.count(w) for w in FIRST_PERSON)
    second_person = sum(words_lower.count(w) for w in SECOND_PERSON)

    imperative = sum(words_lower.count(w) for w in IMPERATIVE)
    modal = sum(words_lower.count(w) for w in MODAL)

    uncertainty = sum(words_lower.count(w) for w in UNCERTAINTY)
    technical = sum(words_lower.count(w) for w in TECHNICAL)
    promotional = sum(words_lower.count(w) for w in PROMOTIONAL)

    # Email specific
    email_count = text.count("@")
    uppercase_ratio_email = uppercase_word_ratio
    attachment_mentions = sum(text.lower().count(w) for w in ["attachment","attached","file","document","pdf"])

    # Complexity
    vectorizer2 = CountVectorizer(ngram_range=(2,2))
    vectorizer3 = CountVectorizer(ngram_range=(3,3))

    try:
        bigram_count = len(vectorizer2.fit([text]).get_feature_names_out())
    except:
        bigram_count = 0

    try:
        trigram_count = len(vectorizer3.fit([text]).get_feature_names_out())
    except:
        trigram_count = 0

    word_length_variation = np.std([len(w) for w in words]) if len(words) > 1 else 0

    # Stylistic
    politeness_markers = sum(words_lower.count(w) for w in POLITE)
    aggressiveness_markers = sum(words_lower.count(w) for w in AGGRESSIVE)
    urgency_markers = sum(words_lower.count(w) for w in URGENCY)

    conditional_phrases = sum(words_lower.count(w) for w in CONDITIONAL)
    personalization_markers = sum(words_lower.count(w) for w in PERSONALIZATION)

    pronoun_count = sum(words_lower.count(p) for p in PRONOUNS)
    conjunction_count = sum(words_lower.count(c) for c in CONJUNCTIONS)

    stopword_ratio = sum(words_lower.count(w) for w in FUNCTION_WORDS) / word_count
    
    avg_syllables_per_word = np.mean([textstat.syllable_count(w) for w in words]) if words else 0

    # Final Feature List
    features = [

        word_count,char_count,avg_word_length,sentence_count,
        avg_sentence_length,unique_word_count,lexical_diversity,
        email_symbol_count,uppercase_word_count,uppercase_word_ratio,
        complex_words_count,

        comma_count,semicolon_count,colon_count,exclamation_count,
        quotation_count,dash_count,sentence_complexity_ratio,
        clause_density,pronoun_density,preposition_density,
        function_word_density,

        *punctuation_freq,
        punctuation_variety,

        flesch,smog,dale,coleman,gunning,

        first_person,second_person,imperative,modal,
        uncertainty,technical,promotional,

        email_count,uppercase_ratio_email,attachment_mentions,

        bigram_count,trigram_count,word_length_variation,

        politeness_markers,aggressiveness_markers,urgency_markers,
        conditional_phrases,personalization_markers,
        pronoun_count,conjunction_count,stopword_ratio,
        avg_syllables_per_word
    ]

    return features

# Load Dataset
if __name__ == "__main__":
    df = pd.read_csv("phishing_email_cleaned_stylometric.csv")

    print("Jumlah data:", len(df))

# Feature Extraction
    features = []

    for i, text in enumerate(df["clean_text"]):

        features.append(extract_60_features(text))

        if i % 5000 == 0:
            print("Processed:", i)

    X = pd.DataFrame(features, columns=feature_names)

    X["label"] = df["label"]

    print("Jumlah fitur:", X.shape[1]-1)

# Save Results
    X.to_csv("stylometric_features_60.csv", index=False)

    print("File stylometric_features_60.csv berhasil dibuat")