# ==========================================================
# SVM GRIDSEARCH + HEATMAP VISUALIZATION
# Stylometric Phishing Detection
# ==========================================================

import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

import matplotlib.pyplot as plt
import seaborn as sns

import joblib

# ----------------------------------------------------------
# 1. LOAD DATASET
# ----------------------------------------------------------

print("Loading dataset...")

df = pd.read_csv("stylometric_features_60.csv")

print("Jumlah data:", df.shape)

# ----------------------------------------------------------
# 2. SPLIT FEATURES DAN LABEL
# ----------------------------------------------------------

X = df.drop("label", axis=1)
y = df["label"]

print("Jumlah fitur:", X.shape[1])

# ----------------------------------------------------------
# 3. TRAIN TEST SPLIT
# ----------------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("Train size:", X_train.shape)
print("Test size :", X_test.shape)

# ----------------------------------------------------------
# 4. FEATURE SCALING
# ----------------------------------------------------------

scaler = StandardScaler()

X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ----------------------------------------------------------
# 5. GRID SEARCH
# ----------------------------------------------------------

print("\nMelakukan GridSearchCV...")

param_grid = {
    "C": [1, 10, 50, 100, 200, 500],
    "gamma": ["scale", 0.1, 0.05, 0.01, 0.005, 0.001],
    "kernel": ["rbf"],
    "class_weight": [None, "balanced"]
}

grid = GridSearchCV(
    SVC(probability=True),
    param_grid,
    cv=5,
    scoring="roc_auc",
    n_jobs=-1,
    verbose=2
)

print("\nMelakukan training + tuning model...")

grid.fit(X_train_scaled, y_train)

# ----------------------------------------------------------
# 6. HASIL TERBAIK
# ----------------------------------------------------------

print("\n===== BEST PARAMETERS =====")
print(grid.best_params_)

print("\n===== BEST ROC-AUC =====")
print(grid.best_score_)

# ----------------------------------------------------------
# 7. SIMPAN GRID SEARCH
# ----------------------------------------------------------

joblib.dump(grid, "gridsearch_3.pkl")

print("\nGridSearch berhasil disimpan:")
print("gridsearch_3.pkl")

# ----------------------------------------------------------
# 8. AMBIL HASIL GRID SEARCH
# ----------------------------------------------------------

results = pd.DataFrame(grid.cv_results_)

# ----------------------------------------------------------
# 9. FILTER BERDASARKAN CLASS_WEIGHT TERBAIK
# ----------------------------------------------------------

best_class_weight = grid.best_params_["class_weight"]

heatmap_data = results[
    results["param_class_weight"] == best_class_weight
].copy()

# ----------------------------------------------------------
# 10. UBAH GAMMA MENJADI STRING
# ----------------------------------------------------------
# supaya "scale" dan angka bisa tampil bersama

heatmap_data["param_gamma"] = heatmap_data["param_gamma"].astype(str)

# ----------------------------------------------------------
# 11. PIVOT TABLE
# ----------------------------------------------------------

pivot_table = heatmap_data.pivot_table(
    values="mean_test_score",
    index="param_C",
    columns="param_gamma"
)

# ----------------------------------------------------------
# 12. URUTKAN KOLOM GAMMA
# ----------------------------------------------------------

gamma_order = ["scale", "0.1", "0.05", "0.01", "0.005", "0.001"]

pivot_table = pivot_table[gamma_order]

# ----------------------------------------------------------
# 13. VISUALISASI HEATMAP
# ----------------------------------------------------------

plt.figure(figsize=(10, 7))

sns.heatmap(
    pivot_table,
    annot=True,
    fmt=".4f",
    cmap="YlGnBu"
)

plt.title("GridSearch Heatmap SVM-RBF (ROC-AUC)")
plt.xlabel("Gamma")
plt.ylabel("C")

plt.savefig(
    "gridsearch_heatmap.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print("\nHeatmap berhasil disimpan:")
print("gridsearch_heatmap.png")