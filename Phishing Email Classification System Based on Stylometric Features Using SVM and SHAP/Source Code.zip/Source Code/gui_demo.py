
# Sistem Klasifikasi Email

import os
import base64
import re
from statistics import pstdev
from collections import Counter

import streamlit as st
import numpy as np
import pandas as pd
import joblib
import shap
import textstat
import nltk

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize

from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

# 1. Setup Streamlit
st.set_page_config(page_title="StylDetect", layout="wide", page_icon="📧")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

/* ── Warna dasar ── */
:root {
    --bg:        #0f1117;
    --surface:   #181c27;
    --surface2:  #1f2436;
    --border:    #2a3050;
    --accent:    #4f8ef7;
    --accent2:   #7bb3ff;
    --danger:    #e05757;
    --success:   #3ecf8e;
    --text:      #e8eaf2;
    --muted:     #8b92ad;
    --tag-bg:    #1a2240;
}

/* ── Reset & background ── */
html, body, [data-testid="stAppViewContainer"] {
    background-color: var(--bg) !important;
    color: var(--text) !important;
    font-family: 'DM Sans', sans-serif !important;
}

/* Grid titik-titik samar di background */
[data-testid="stAppViewContainer"]::before {
    content: "";
    position: fixed;
    inset: 0;
    background-image:
        radial-gradient(circle, rgba(79,142,247,0.07) 1px, transparent 1px);
    background-size: 28px 28px;
    pointer-events: none;
    z-index: 0;
}

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background-color: var(--surface) !important;
    border-right: 1px solid var(--border) !important;
}
[data-testid="stSidebar"] * { color: var(--text) !important; }

/* ── Konten utama ── */
.block-container {
    padding: 2rem 3rem !important;
    max-width: 960px !important;
    position: relative;
    z-index: 1;
}

/* ── Heading kustom ── */
.styldetect-hero {
    margin-bottom: 0.25rem;
}
.styldetect-hero h1 {
    font-family: 'Instrument Serif', Georgia, serif !important;
    font-size: 2.8rem !important;
    font-weight: 400 !important;
    letter-spacing: -0.5px;
    color: var(--text) !important;
    margin-bottom: 0 !important;
}
.styldetect-hero h1 span {
    color: var(--accent) !important;
    font-style: italic;
}
.styldetect-subtitle {
    font-size: 0.97rem;
    color: var(--muted);
    margin-top: 0.3rem;
    margin-bottom: 1.6rem;
    letter-spacing: 0.01em;
}

/* ── Divider ── */
hr {
    border: none !important;
    border-top: 1px solid var(--border) !important;
    margin: 1.4rem 0 !important;
}

/* ── Card / Surface ── */
.sd-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 1.4rem 1.6rem;
    margin-bottom: 1.2rem;
}
.sd-label {
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    color: var(--muted);
    margin-bottom: 0.5rem;
    font-weight: 500;
}

/* ── Result badge ── */
.sd-result-phishing {
    display: inline-block;
    background: rgba(224,87,87,0.13);
    border: 1px solid var(--danger);
    color: var(--danger);
    border-radius: 999px;
    padding: 0.35rem 1.1rem;
    font-weight: 600;
    font-size: 0.95rem;
}
.sd-result-legit {
    display: inline-block;
    background: rgba(62,207,142,0.12);
    border: 1px solid var(--success);
    color: var(--success);
    border-radius: 999px;
    padding: 0.35rem 1.1rem;
    font-weight: 600;
    font-size: 0.95rem;
}

/* ── Tag kecil ── */
.sd-tag {
    display: inline-block;
    background: var(--tag-bg);
    color: var(--accent2);
    border-radius: 6px;
    padding: 0.15rem 0.55rem;
    font-size: 0.78rem;
    font-weight: 500;
    margin-right: 0.3rem;
}

/* ── Radio button ── */
[data-testid="stRadio"] > div {
    gap: 0.6rem !important;
}
[data-testid="stRadio"] label {
    background: var(--surface2) !important;
    border: 1px solid var(--border) !important;
    border-radius: 10px !important;
    padding: 0.55rem 1.1rem !important;
    cursor: pointer !important;
    transition: border-color 0.2s !important;
    color: var(--text) !important;
    font-size: 0.92rem !important;
}
[data-testid="stRadio"] label:hover {
    border-color: var(--accent) !important;
}

/* ── Textarea ── */
textarea {
    background-color: var(--surface2) !important;
    color: var(--text) !important;
    border: 1px solid var(--border) !important;
    border-radius: 10px !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.9rem !important;
    padding: 0.8rem !important;
    transition: border-color 0.2s !important;
}
textarea:focus {
    border-color: var(--accent) !important;
    box-shadow: 0 0 0 3px rgba(79,142,247,0.12) !important;
}

/* ── Label ── */
label, .stTextArea label, .stSlider label, .stRadio label p {
    color: var(--text) !important;
    font-size: 0.91rem !important;
    font-weight: 500 !important;
}

/* ── Slider ── */
[data-testid="stSlider"] > div > div > div {
    background: var(--accent) !important;
}

/* ── Tombol ── */
.stButton > button {
    background: var(--accent) !important;
    color: #fff !important;
    border: none !important;
    border-radius: 10px !important;
    padding: 0.6rem 1.6rem !important;
    font-family: 'DM Sans', sans-serif !important;
    font-weight: 600 !important;
    font-size: 0.92rem !important;
    letter-spacing: 0.02em !important;
    box-shadow: 0 4px 18px rgba(79,142,247,0.28) !important;
    transition: all 0.2s !important;
}
.stButton > button:hover {
    background: #3a7de8 !important;
    box-shadow: 0 6px 24px rgba(79,142,247,0.42) !important;
    transform: translateY(-1px) !important;
}

/* ── Tabel dataframe ── */
[data-testid="stDataFrame"] {
    border-radius: 10px !important;
    overflow: hidden !important;
}

/* ── Alert ── */
[data-testid="stAlert"] {
    border-radius: 10px !important;
    font-size: 0.92rem !important;
}

/* ── Expander — paksa dark theme di semua versi Streamlit ── */
details {
    background: var(--surface2) !important;
    border: 1px solid var(--border) !important;
    border-radius: 12px !important;
    overflow: hidden !important;
}
details summary {
    background: var(--surface2) !important;
    color: var(--text) !important;
    font-weight: 500 !important;
    font-size: 0.93rem !important;
    padding: 0.75rem 1rem !important;
}
details summary:hover {
    background: var(--surface) !important;
}
details[open] summary {
    border-bottom: 1px solid var(--border) !important;
}
/* konten dalam expander */
details > div,
details > div > div,
[data-testid="stExpander"] > div,
[data-testid="stExpander"] > div > div {
    background: var(--surface) !important;
    color: var(--text) !important;
}
/* semua teks di dalam expander */
[data-testid="stExpander"] p,
[data-testid="stExpander"] span,
[data-testid="stExpander"] label,
[data-testid="stExpander"] div,
[data-testid="stExpander"] strong {
    color: var(--text) !important;
}
/* header expander (class lama & baru) */
.streamlit-expanderHeader,
[data-testid="stExpanderToggleIcon"] {
    background: var(--surface2) !important;
    color: var(--text) !important;
    font-weight: 500 !important;
    font-size: 0.93rem !important;
}
.streamlit-expanderContent {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-top: none !important;
    border-radius: 0 0 12px 12px !important;
}
/* isi body preview */
.sd-body-preview {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.85rem 1rem;
    font-size: 0.85rem;
    color: var(--muted) !important;
    line-height: 1.6;
    white-space: pre-wrap;
    word-break: break-word;
    max-height: 160px;
    overflow-y: auto;
    margin-top: 0.5rem;
    font-family: 'DM Sans', sans-serif;
}

/* ── Spinner ── */
[data-testid="stSpinner"] { color: var(--accent) !important; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
::-webkit-scrollbar-thumb:hover { background: var(--accent); }

/* ── Watermark pojok bawah ── */
.sd-watermark {
    position: fixed;
    bottom: 1.2rem;
    right: 1.5rem;
    font-size: 0.72rem;
    color: var(--border);
    letter-spacing: 0.08em;
    text-transform: uppercase;
    pointer-events: none;
    z-index: 999;
}
</style>

<div class="sd-watermark">StylDetect v1.0</div>
""", unsafe_allow_html=True)

for pkg in ["punkt", "stopwords", "punkt_tab"]:
    try:
        nltk.data.find(f"tokenizers/{pkg}")
    except:
        nltk.download(pkg, quiet=True)

MODEL_PKL   = "svm_rbf_model_3.pkl"
SCALER_PKL  = "scaler_3.pkl"
FEATURE_CSV = "stylometric_features_60.csv"
SCOPES      = ["https://www.googleapis.com/auth/gmail.readonly"]

with open("best_threshold.txt", "r") as f:
    THRESHOLD = float(f.read())

# 2. Preprocessing
def clean_text_stylometric(text: str) -> str:
    text = str(text).replace('\r', '\n')
    text = re.sub(r"<.*?>", " ", text)
    text = re.sub(r"(?i)\bsubject:", " ", text)
    text = re.sub(r"(?i)\bfrom:", " ", text)
    text = re.sub(r"(?i)\bto:", " ", text)
    text = text.replace('\t', ' ')
    text = re.sub(r"[ ]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

# 3. Feature Extraction
from feature_extraction import extract_60_features

train_df     = pd.read_csv("stylometric_features_60.csv")
feature_names = list(train_df.drop(columns=["label"]).columns)

# 4. Load Model, Scaler and SHAP Explainer
@st.cache_resource
def load_model_and_scaler():
    model  = joblib.load(MODEL_PKL)
    scaler = joblib.load(SCALER_PKL)
    return model, scaler

@st.cache_resource
def get_shap_explainer(_model, _scaler):
    df_bg = pd.read_csv(FEATURE_CSV)
    X_bg  = df_bg.drop(columns=["label"]) if "label" in df_bg.columns else df_bg.copy()
    bg_n = min(40, len(X_bg))
    X_bg_scaled = _scaler.transform(X_bg.sample(bg_n, random_state=42).values)
    return shap.KernelExplainer(_model.predict_proba, X_bg_scaled)

# 5. Gmail
@st.cache_resource
def get_gmail_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)

def _get_body_from_message(msg):
    def walk_parts(part):
        mime_type = part.get("mimeType", "")
        if mime_type == "text/plain" and "data" in part.get("body", {}):
            return base64.urlsafe_b64decode(part["body"]["data"]).decode("utf-8", errors="ignore")
        for sub in part.get("parts", []) or []:
            text = walk_parts(sub)
            if text:
                return text
        return ""
    payload = msg.get("payload", {})
    text = walk_parts(payload)
    return text or msg.get("snippet", "")

def fetch_recent_emails(service, max_results=5):
    results  = service.users().messages().list(userId="me", labelIds=["INBOX"], maxResults=max_results).execute()
    messages = results.get("messages", [])
    emails   = []
    for m in messages:
        msg     = service.users().messages().get(userId="me", id=m["id"], format="full").execute()
        headers = msg.get("payload", {}).get("headers", [])
        subject = sender = ""
        for h in headers:
            if h["name"].lower() == "subject": subject = h["value"]
            if h["name"].lower() == "from":    sender  = h["value"]
        emails.append({"subject": subject, "from": sender, "body": _get_body_from_message(msg)})
    return emails

# 6. Klasifikasi dan XAI
def classify_and_explain(email_text, model, scaler, explainer, topk=5):
    cleaned   = clean_text_stylometric(email_text.lower())
    feat_list = extract_60_features(cleaned)
    feat_df   = pd.DataFrame([feat_list], columns=feature_names).reindex(columns=feature_names)
    X_scaled  = np.clip(scaler.transform(feat_df), -3, 3)
    proba     = model.predict_proba(X_scaled)[0][1]
    label_str = "Phishing" if proba >= THRESHOLD else "Legitimate"

    shap_values = explainer.shap_values(X_scaled, nsamples=100)
    if isinstance(shap_values, list):
        shap_ph = shap_values[1][0]
    else:
        shap_ph = shap_values[0, :, 1] if shap_values.ndim == 3 else shap_values[0]

    s = pd.Series(shap_ph, index=feature_names)
    top_features = s.abs().sort_values(ascending=False).head(topk).index

    explanation_rows = []
    for fname in top_features:
        val  = s[fname]
        arah = "mendorong ke phishing" if val > 0 else "mendorong ke legitimate"
        explanation_rows.append({"Fitur": fname, "Nilai SHAP": f"{val:.4f}", "Arah": arah})

    return label_str, float(proba), pd.DataFrame(explanation_rows)

@st.cache_data(show_spinner=False)
def classify_and_explain_cached(email_text, topk=5):
    return classify_and_explain(email_text, model, scaler, explainer, topk=topk)

# 7. UI
# Hero header
st.markdown("""
<div class="styldetect-hero">
  <h1>📧 <span>StylDetect</span></h1>
</div>
<p class="styldetect-subtitle">
  Sistem Klasifikasi Email Phishing Berbasis Fitur Stylometric.
</p>
""", unsafe_allow_html=True)

st.markdown("---")

# Informasi singkat
col1, col2, col3 = st.columns(3)
with col1:
    st.markdown("""
    <div class="sd-card">
      <div class="sd-label">Metode</div>
      <div style="font-size:1.05rem;font-weight:600;">SVM + RBF Kernel</div>
      <div style="font-size:0.82rem;color:var(--muted);margin-top:0.2rem;">Support Vector Machine</div>
    </div>
    """, unsafe_allow_html=True)
with col2:
    st.markdown("""
    <div class="sd-card">
      <div class="sd-label">Jumlah Fitur</div>
      <div style="font-size:1.05rem;font-weight:600;">60 Fitur Stylometric</div>
      <div style="font-size:0.82rem;color:var(--muted);margin-top:0.2rem;">Analisis Gaya Penulisan</div>
    </div>
    """, unsafe_allow_html=True)
with col3:
    st.markdown("""
    <div class="sd-card">
      <div class="sd-label">Explainability</div>
      <div style="font-size:1.05rem;font-weight:600;">SHAP</div>
      <div style="font-size:0.82rem;color:var(--muted);margin-top:0.2rem;">Penjelasan Prediksi</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("---")

# Pilih Mode
st.markdown("**Dari mana email yang ingin dianalisis?**")
mode = st.radio(
    label="mode_selector",
    options=("Ketik / Tempel Email", "Mengambil dari Gmail"),
    label_visibility="collapsed"
)

model, scaler = load_model_and_scaler()
explainer     = get_shap_explainer(model, scaler)

# Mode 1 - Input Manual
if mode == "Ketik / Tempel Email":

    st.markdown("#### Ketik atau tempel isi email")
    st.caption("Ketik atau tempel isi email, lalu klik tombol analisis. Harap gunakan Bahasa Inggris.")

    default_text = """Hi,

Your account will be blocked in 24 hours. Please click the link below to verify your identity immediately.

Best regards,
Support Team"""

    email_input = st.text_area(
        label="Isi email",
        value=default_text,
        height=220,
        label_visibility="collapsed",
        placeholder="Tempel isi email di sini..."
    )

    topk = st.slider(
        "Berapa fitur paling berpengaruh yang ingin ditampilkan?",
        min_value=3, max_value=15, value=5
    )

    if st.button("🔍  Analisis Email"):
        if not email_input.strip():
            st.warning("Belum ada teks email yang dimasukkan.")
        else:
            with st.spinner("Sedang menganalisis..."):
                label_str, proba, explanation_df = classify_and_explain_cached(
                    email_input, topk=topk
                )

            st.markdown("---")
            st.markdown("#### Hasil Analisis")

            if label_str == "Phishing":
                st.markdown(f"""
                <div class="sd-card" style="border-color:var(--danger);">
                  <div class="sd-label">Status Email</div>
                  <div class="sd-result-phishing">🚨 Phishing Terdeteksi</div>
                  <div style="margin-top:0.7rem;font-size:0.9rem;color:var(--muted);">
                    Skor kepercayaan phishing: <strong style="color:var(--text);">{proba:.1%}</strong>
                    &nbsp;<span class="sd-tag">di atas threshold {THRESHOLD:.2f}</span>
                  </div>
                  <div style="margin-top:0.5rem;font-size:0.85rem;color:var(--muted);">
                    ⚠️ Jangan klik tautan atau lampiran dalam email ini.
                  </div>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown(f"""
                <div class="sd-card" style="border-color:var(--success);">
                  <div class="sd-label">Status Email</div>
                  <div class="sd-result-legit">✅ Email Aman</div>
                  <div style="margin-top:0.7rem;font-size:0.9rem;color:var(--muted);">
                    Skor kepercayaan phishing: <strong style="color:var(--text);">{proba:.1%}</strong>
                    &nbsp;<span class="sd-tag">di bawah threshold {THRESHOLD:.2f}</span>
                  </div>
                  <div style="margin-top:0.5rem;font-size:0.85rem;color:var(--muted);">
                    Model menilai email ini tidak memiliki pola mencurigakan.
                  </div>
                </div>
                """, unsafe_allow_html=True)

            st.markdown("#### Fitur yang Paling Mempengaruhi Keputusan Model")
            st.caption(
                "Nilai SHAP Positif mendorong ke arah phishing. " 
                "Nilai SHAP Negatif mendorong ke arah legitimate."
            )
            st.dataframe(explanation_df, use_container_width=True, hide_index=True)

# Mode 2 - Gmail
else:
    st.markdown("#### Analisis Email dari Kotak Masuk Gmail")
    st.caption(
        "Sistem meminta izin membaca Gmail (read-only). "
        "Email tidak disimpan ke mana pun dan hanya dianalisis secara lokal."
    )

    num_email = st.slider("Berapa email terbaru yang ingin dianalisis?", 1, 10, 5)

    if st.button("📥  Hubungkan Gmail & Mulai Analisis"):
        with st.spinner("Menghubungkan ke Gmail dan mengambil email..."):
            service = get_gmail_service()
            emails  = fetch_recent_emails(service, max_results=num_email)

        if not emails:
            st.warning("Tidak ada email yang ditemukan di kotak masuk.")
        else:
            st.markdown("---")
            st.markdown(f"#### Hasil Analisis {len(emails)} Email Terbaru")

            progress_bar  = st.progress(0, text="Memulai analisis...")
            results_placeholder = []

            for i, em in enumerate(emails, start=1):
                progress_bar.progress(
                    (i - 1) / len(emails),
                    text=f"Menganalisis email {i} dari {len(emails)}..."
                )
                label_str, proba, explanation_df = classify_and_explain_cached(
                    em["body"], topk=5
                )
                results_placeholder.append((em, label_str, proba, explanation_df))

            progress_bar.progress(1.0, text="Analisis selesai.")
            progress_bar.empty()

            for i, (em, label_str, proba, explanation_df) in enumerate(results_placeholder, start=1):
                icon    = "🚨" if label_str == "Phishing" else "✅"
                subject = em["subject"] or "(tanpa subjek)"

                with st.expander(f"{icon}  {i}. {subject}", expanded=False):

                    # Info pengirim
                    st.markdown(f"""
                    <div style="display:flex;gap:0.5rem;flex-wrap:wrap;margin-bottom:0.6rem;">
                      <span><span class='sd-tag'>Dari</span>
                        <span style="color:#e8eaf2;font-size:0.88rem;">{em['from']}</span>
                      </span>
                    </div>
                    """, unsafe_allow_html=True)

                    # Preview isi email
                    body_preview = (em["body"] or "").strip()
                    body_short   = body_preview[:600] + ("..." if len(body_preview) > 600 else "")
                    # escape karakter HTML agar tidak merusak layout
                    body_escaped = (body_short
                                    .replace("&", "&amp;")
                                    .replace("<", "&lt;")
                                    .replace(">", "&gt;"))
                    st.markdown(f"""
                    <div class="sd-label" style="margin-top:0.2rem;">Cuplikan Isi Email</div>
                    <div class="sd-body-preview">{body_escaped if body_escaped else '<i style="color:#555">— isi email kosong atau tidak terbaca —</i>'}</div>
                    """, unsafe_allow_html=True)

                    st.markdown("<div style='height:0.8rem'></div>", unsafe_allow_html=True)

                    # Hasil deteksi
                    if label_str == "Phishing":
                        st.markdown(f"""
                        <div class="sd-card" style="border-color:#e05757;margin-top:0.2rem;">
                          <div class="sd-label">Hasil Deteksi</div>
                          <div class="sd-result-phishing">🚨 Phishing Terdeteksi</div>
                          <div style="margin-top:0.6rem;font-size:0.88rem;color:#8b92ad;">
                            Skor kepercayaan phishing: <strong style="color:#e8eaf2;">{proba:.1%}</strong>
                          </div>
                          <div style="margin-top:0.3rem;font-size:0.82rem;color:#8b92ad;">
                            ⚠️ Jangan klik tautan atau lampiran dalam email ini.
                          </div>
                        </div>
                        """, unsafe_allow_html=True)
                    else:
                        st.markdown(f"""
                        <div class="sd-card" style="border-color:#3ecf8e;margin-top:0.2rem;">
                          <div class="sd-label">Hasil Deteksi</div>
                          <div class="sd-result-legit">✅ Email Aman</div>
                          <div style="margin-top:0.6rem;font-size:0.88rem;color:#8b92ad;">
                            Skor kepercayaan phishing: <strong style="color:#e8eaf2;">{proba:.1%}</strong>
                          </div>
                        </div>
                        """, unsafe_allow_html=True)

                    # Tabel SHAP
                    st.markdown("<div class='sd-label' style='margin-top:0.8rem;'>Fitur Paling Berpengaruh</div>", unsafe_allow_html=True)
                    st.dataframe(explanation_df, use_container_width=True, hide_index=True)

            st.markdown("---")