import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

# ==========================================================
# Load model
# ==========================================================

model = joblib.load("svm_rbf_model_3.pkl")

# ==========================================================
# Load dataset (harus sama seperti saat training)
# ==========================================================

df = pd.read_csv("stylometric_features_60.csv")

X = df.drop("label", axis=1)
y = df["label"]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# ==========================================================
# Summary Support Vector
# ==========================================================

pd.DataFrame({
    "kelas": model.classes_,
    "jumlah_support_vector": model.n_support_
}).to_csv("support_vector_summary.csv", index=False)

# ==========================================================
# Support Vector + nomor baris data latih
# ==========================================================

support_vector_df = pd.DataFrame(
    model.support_vectors_,
    columns=X.columns
)

support_vector_df.insert(
    0,
    "Training_Row_Index",
    model.support_
)

support_vector_df.insert(
    0,
    "Support_Vector_No",
    range(1, len(support_vector_df)+1)
)

support_vector_df.to_csv(
    "support_vectors.csv",
    index=False
)

# ==========================================================
# Alpha
# ==========================================================

alphas = np.abs(model.dual_coef_[0])

pd.DataFrame({
    "Support_Vector_No": range(1, len(alphas)+1),
    "alpha": alphas
}).to_csv(
    "alpha_values.csv",
    index=False
)

# ==========================================================
# Bias
# ==========================================================

pd.DataFrame({
    "bias": model.intercept_
}).to_csv(
    "bias.csv",
    index=False
)

# ==========================================================
# Platt Scaling
# ==========================================================

pd.DataFrame({
    "probA": model.probA_,
    "probB": model.probB_
}).to_csv(
    "platt_scaling_parameters.csv",
    index=False
)