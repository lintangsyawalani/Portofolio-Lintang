import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
 
# ============================================================
# 1. Memuat dataset penuh
# ============================================================
df = pd.read_csv("stylometric_features_60.csv")
 
X = df.drop("label", axis=1)
y = df["label"]
 
# ============================================================
# 2. Membagi ulang data dengan parameter split YANG SAMA seperti
#    training asli, supaya X_test & y_test identik dengan sebelumnya
# ============================================================
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)
 
print("Test size:", X_test.shape)
 
# ============================================================
# 3. Memuat model, scaler, dan parameter Platt Scaling
# ============================================================
model = joblib.load("svm_rbf_model_3.pkl")
scaler = joblib.load("scaler_3.pkl")
 
platt_params = pd.read_csv("platt_scaling_parameters.csv")
A = platt_params.loc[0, "probA"]
B = platt_params.loc[0, "probB"]
print(f"A = {A}")
print(f"B = {B}")
 
# ============================================================
# 4. Menormalisasi X_test memakai scaler yang sama seperti training
#    (HANYA transform, tanpa fit ulang, supaya tidak ada data leakage)
# ============================================================
X_test_scaled = scaler.transform(X_test)
 
# ============================================================
# 5. Menghitung nilai fungsi keputusan f(x) untuk seluruh data uji
# ============================================================
# f(x) = sum(alpha_i * y_i * K(x_i, x)) + b, dihitung otomatis oleh
# scikit-learn menggunakan seluruh support vector hasil pelatihan
decision_function = model.decision_function(X_test_scaled)
 
# ============================================================
# 6. Mengubah decision_function menjadi probabilitas lewat Platt Scaling
# ============================================================
# rumus: P(y=1|x) = 1 / (1 + exp(A * f(x) + B))
probabilitas = 1 / (1 + np.exp(A * decision_function + B))
 
# ============================================================
# 7. Menentukan label prediksi berdasarkan threshold hasil tuning
# ============================================================
with open("best_threshold.txt") as f:
    THRESHOLD = float(f.read())
print(f"Threshold = {THRESHOLD}")
 
predicted_label = (probabilitas >= THRESHOLD).astype(int)
predicted_label_str = np.where(predicted_label == 1, "Phishing", "Legitimate")
status = np.where(predicted_label == y_test.to_numpy(), "Benar", "Salah")
 
# ============================================================
# 8. Menggabungkan semuanya ke dalam satu tabel
# ============================================================
hasil = pd.DataFrame({
    "row_id": np.arange(1, len(decision_function) + 1),
    "decision_function": decision_function,
    "predicted_proba_phishing": probabilitas,
    "predicted_label": predicted_label,
    "predicted_label_str": predicted_label_str,
    "threshold": THRESHOLD,
    "true_label": y_test.to_numpy(),
    "status": status,
})
 
# ============================================================
# 9. Menampilkan beberapa baris pertama sebagai pengecekan
# ============================================================
print(hasil.head(10))
print(f"\nTotal data uji: {len(hasil)}")
 
# ============================================================
# 10. Menyimpan hasil ke file CSV
# ============================================================
hasil.to_csv("svm_predictions_full_datauji.csv", index=False)
print("\nHasil lengkap disimpan ke: svm_predictions_full_datauji.csv")