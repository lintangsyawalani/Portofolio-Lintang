"""
Kode ini melanjutkan pipeline SHAP untuk SELURUH data (82.486 baris, 60 fitur).
Berbeda dari versi sebelumnya, di sini model, data, dan nama fitur
BENAR-BENAR dimuat di dalam file ini, bukan sekadar diasumsikan sudah ada,
supaya file ini bisa dijalankan sendiri tanpa error "is not defined".
"""

import numpy as np
import pandas as pd
import joblib
import shap

# ========== 0. Memuat model, scaler, dan data (BAGIAN YANG SEBELUMNYA HILANG) ==========
model = joblib.load("svm_rbf_model_3.pkl")
scaler = joblib.load("scaler_3.pkl")

df = pd.read_csv("stylometric_features_60.csv")
feature_names = [kol for kol in df.columns if kol != "label"]
X = df[feature_names]

X_scaled = scaler.transform(X)
print("X_scaled shape:", X_scaled.shape)
print("Jumlah fitur:", len(feature_names))

# ========== 1. Membentuk background data ==========
np.random.seed(42)  # supaya hasil bisa direproduksi ulang
bg_size = min(300, X_scaled.shape[0])
bg_idx = np.random.choice(X_scaled.shape[0], bg_size, replace=False)
X_bg = X_scaled[bg_idx]

# ========== 2. Membentuk SHAP explainer ==========
explainer = shap.KernelExplainer(model.predict_proba, X_bg)

if isinstance(explainer.expected_value, (list, np.ndarray)):
    base_val = explainer.expected_value[1]
else:
    base_val = explainer.expected_value
print("Base value (kelas phishing):", base_val)

# ========== 3. Menghitung nilai SHAP untuk background data ==========
shap_values = explainer.shap_values(X_bg, nsamples=500)

if isinstance(shap_values, list):
    shap_values_pos = shap_values[1]
elif len(shap_values.shape) == 3:
    shap_values_pos = shap_values[:, :, 1]
else:
    shap_values_pos = shap_values

# ========== 4. Nilai SHAP untuk 5 data contoh (x1..x5) ==========
X_5data = X_scaled[:5]
shap_5data = explainer.shap_values(X_5data, nsamples=500)

if isinstance(shap_5data, list):
    shap_5data_pos = shap_5data[1]
elif len(shap_5data.shape) == 3:
    shap_5data_pos = shap_5data[:, :, 1]
else:
    shap_5data_pos = shap_5data

df_5data = pd.DataFrame(
    shap_5data_pos,
    columns=feature_names,
    index=[f"x{i+1}" for i in range(5)]
)
df_5data.to_csv("shap_values_5data.csv", index=True)
print("\nNilai SHAP untuk x1..x5 disimpan ke shap_values_5data.csv")
print(df_5data)

# ========== 5. Ranking mean absolute SHAP (feature importance) ==========
mean_abs_shap = np.abs(shap_values_pos).mean(axis=0)
importance_df = pd.DataFrame({
    "Feature": feature_names,
    "Mean_SHAP_Importance": mean_abs_shap
})
importance_df = importance_df.sort_values(
    by="Mean_SHAP_Importance",
    ascending=False
)
importance_df.to_csv("shap_feature_importance.csv", index=False)
print("\nRanking feature importance disimpan ke shap_feature_importance.csv")
print(importance_df.head(10))

# ========== 6. (Opsional) Seluruh nilai SHAP untuk seluruh background data ==========
df_all = pd.DataFrame(shap_values_pos, columns=feature_names)
df_all.to_csv("shap_values_all_background.csv", index=False)
print("\nSeluruh nilai SHAP (300 background data) disimpan ke shap_values_all_background.csv")