import numpy as np
import itertools
import math

# 5 data contoh (hasil normalisasi)
X = np.array([
    [-0.252574, -0.071553, -1.115997, 0.0, -1.835825],  # x1
    [ 0.081696, -0.013259, -0.945790, 0.0, -0.877465],  # x2 (support vector)
    [-0.228451, -0.066743, -0.880898, 0.0, -0.873193],  # x3 (support vector)
    [ 0.285015,  0.041675, -0.542122, 0.0, -0.387560],  # x4 (support vector)
    [-0.066485, -0.032323, -0.583228, 0.0, -0.964236],  # x5 (support vector)
])
y = np.array([-1, -1, -1, 1, 1])
feature_names = ['word_count', 'char_count', 'avg_word_length',
                  'stopword_ratio', 'avg_syllables_per_word']

# Parameter model hasil pelatihan sebelumnya
gamma = 0.1
alpha = np.array([0, 33.4009, 55.9358, 4.5769, 84.7599])
b = -0.0183
support_idx = [1, 2, 3, 4]          # index x2..x5

# Parameter Platt Scaling (dikalibrasi ke x1 dan x4)
A, B = 2.9128528948263397, 0.01156583074262453


def kernel_rbf(a, c, gamma=gamma):
    """Kernel RBF: K(a,c) = exp(-gamma * ||a-c||^2)"""
    jarak_kuadrat = np.sum((a - c) ** 2)
    return np.exp(-gamma * jarak_kuadrat)


def decision_function(x):
    """f(x) = sum(alpha_i * y_i * K(x_i, x)) + b"""
    total = 0.0
    for j in support_idx:
        total += alpha[j] * y[j] * kernel_rbf(X[j], x)
    return total + b


def predict_proba(x):
    """Ubah decision_function menjadi probabilitas via Platt Scaling"""
    f = decision_function(x)
    return 1 / (1 + np.exp(-(A * f + B)))


def buat_data_hybrid(S, x_target, x_base):
    """Fitur di S diambil dari x_target, sisanya dari x_base"""
    x_hybrid = x_base.copy()
    for idx in S:
        x_hybrid[idx] = x_target[idx]
    return x_hybrid


def hitung_shap(feature_idx, x_target, x_base, n_fitur=5, verbose=False):
    """Hitung nilai SHAP satu fitur dengan enumerasi seluruh kombinasi S"""
    fitur_lain = [k for k in range(n_fitur) if k != feature_idx]
    phi = 0.0
    hasil_tabel = []

    # enumerasi seluruh subset S dari fitur_lain (2^4 = 16 kombinasi)
    for ukuran in range(len(fitur_lain) + 1):
        for S in itertools.combinations(fitur_lain, ukuran):
            S = list(S)
            bobot = (math.factorial(len(S)) *
                     math.factorial(n_fitur - len(S) - 1) /
                     math.factorial(n_fitur))

            x_S = buat_data_hybrid(S, x_target, x_base)
            x_Sj = buat_data_hybrid(S + [feature_idx], x_target, x_base)

            f_S = predict_proba(x_S)
            f_Sj = predict_proba(x_Sj)
            kontribusi = bobot * (f_Sj - f_S)
            phi += kontribusi

            if verbose:
                nama_S = [feature_names[k] for k in S] if S else ['-']
                hasil_tabel.append((len(S), nama_S, bobot, f_S, f_Sj, kontribusi))

    return phi, hasil_tabel


# ==== Menjalankan perhitungan untuk data x4 dibanding baseline x1 ====
x_target = X[3]   # x4 (data yang dijelaskan)
x_base = X[0]      # x1 (baseline)

print("=== Tabel lengkap untuk fitur avg_word_length ===")
phi_awl, tabel = hitung_shap(2, x_target, x_base, verbose=True)
for baris in tabel:
    ukuran, fitur_S, bobot, fS, fSj, kontrib = baris
    print(f"|S|={ukuran} S={fitur_S} bobot={bobot:.4f} "
          f"f(S)={fS:.4f} f(S+i)={fSj:.4f} kontribusi={kontrib:.4f}")
print(f"\nphi(avg_word_length) = {phi_awl:.4f}")

print("\n=== Nilai SHAP seluruh fitur ===")
total_phi = 0
for i, nama in enumerate(feature_names):
    phi, _ = hitung_shap(i, x_target, x_base)
    total_phi += phi
    print(f"{nama}: phi = {phi:.4f}")

print(f"\nJumlah seluruh phi = {total_phi:.4f}")
print(f"f(x4) - f(x1) = {predict_proba(x_target) - predict_proba(x_base):.4f}")