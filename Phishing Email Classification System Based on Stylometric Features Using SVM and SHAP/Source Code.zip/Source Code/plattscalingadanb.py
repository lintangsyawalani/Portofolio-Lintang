import numpy as np

def platt_scaling(f, y, maxiter=100):
    f = np.array(f, dtype=float)
    y = np.array(y, dtype=float)          # label 0/1
    prior1 = np.sum(y == 1)
    prior0 = np.sum(y == 0)
    t = np.where(y == 1,
                 (prior1 + 1) / (prior1 + 2),
                 1 / (prior0 + 2))         # target peluang

    A, B = 0.0, np.log((prior0 + 1) / (prior1 + 1))
    lamb = 1e-3

    p0 = 1 / (1 + np.exp(f * A + B))
    p0 = np.clip(p0, 1e-300, 1 - 1e-300)
    olderr = -np.sum(t * np.log(p0) + (1 - t) * np.log(1 - p0))

    for _ in range(maxiter):
        p = 1 / (1 + np.exp(f * A + B))
        d2 = p * (1 - p)                  # bobot Hessian
        a  = np.sum(f * f * d2) + lamb
        bb = np.sum(d2) + lamb
        c  = np.sum(f * d2)
        d  = np.sum(f * (t - p))          # gradien terhadap A
        e  = np.sum(t - p)                # gradien terhadap B

        if abs(d) < 1e-9 and abs(e) < 1e-9:
            break

        det = a * bb - c * c
        dA = (bb * d - c * e) / det
        dB = (a * e - c * d) / det

        stepsize = 1.0
        found = False
        while stepsize >= 1e-10:
            # PERBAIKAN: dikurangi (A - dA), bukan ditambah,
            # karena d dan e adalah gradien asli (bukan negatifnya)
            newA, newB = A - stepsize * dA, B - stepsize * dB
            pnew = 1 / (1 + np.exp(f * newA + newB))
            pnew = np.clip(pnew, 1e-300, 1 - 1e-300)
            newerr = -np.sum(t * np.log(pnew) + (1 - t) * np.log(1 - pnew))
            if newerr < olderr:
                A, B, olderr = newA, newB, newerr
                found = True
                break
            stepsize /= 2.0
        if not found:
            break
    return A, B

# 5 data contoh
f_train = [-1.1844, -1.0, -1.0, 1.0, 1.0]
y_train = [0, 0, 0, 1, 1]

A, B = platt_scaling(f_train, y_train)
print("A =", A, " B =", B)