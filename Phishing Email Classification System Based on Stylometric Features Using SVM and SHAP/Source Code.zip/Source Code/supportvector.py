# ==========================================================
# SUPPORT VECTOR ANALYSIS
# Load trained SVM-RBF model
# ==========================================================

import pandas as pd
import joblib
from sklearn.model_selection import train_test_split

# ----------------------------------------------------------
# 1. LOAD DATASET
# ----------------------------------------------------------

print("Loading dataset...")

df = pd.read_csv("stylometric_features_60.csv")

X = df.drop("label", axis=1)
y = df["label"]

# ----------------------------------------------------------
# 2. TRAIN TEST SPLIT
# (harus sama seperti training asli)
# ----------------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# ----------------------------------------------------------
# 3. LOAD SCALER
# ----------------------------------------------------------

print("Loading scaler...")

scaler = joblib.load("scaler_3.pkl")

X_train_scaled = scaler.transform(X_train)

# ----------------------------------------------------------
# 4. LOAD TRAINED MODEL
# ----------------------------------------------------------

print("Loading trained SVM model...")

model = joblib.load("svm_rbf_model_3.pkl")

# ----------------------------------------------------------
# 5. SUPPORT VECTOR ANALYSIS
# ----------------------------------------------------------

print("\n===== SUPPORT VECTOR ANALYSIS =====")

sv_per_class = model.n_support_
total_sv = len(model.support_vectors_)
train_size = X_train_scaled.shape[0]
sv_percentage = (total_sv / train_size) * 100

print("Support vector per class:", sv_per_class)
print("Total support vectors:", total_sv)
print("Training samples:", train_size)
print(f"Support vector percentage: {sv_percentage:.2f}%")

# ----------------------------------------------------------
# 6. SAVE TO CSV
# ----------------------------------------------------------

sv_df = pd.DataFrame({
    "Information": [
        "Support Vector (Class 0)",
        "Support Vector (Class 1)",
        "Total Support Vector",
        "Training Samples",
        "Support Vector Percentage (%)"
    ],
    "Value": [
        sv_per_class[0],
        sv_per_class[1],
        total_sv,
        train_size,
        round(sv_percentage, 2)
    ]
})

sv_df.to_csv("support_vector_analysis.csv", index=False)

print("\nSupport vector analysis saved:")
print("support_vector_analysis.csv")