import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)

# ==========================================
# LOAD DATA
# ==========================================

df = pd.read_csv("stylometric_features_60.csv")

X = df.drop("label", axis=1)
y = df["label"]

# ==========================================
# SPLIT DATA (HARUS SAMA DENGAN TRAINING)
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# ==========================================
# LOAD SCALER + MODEL
# ==========================================

scaler = joblib.load("scaler_3.pkl")
model = joblib.load("svm_rbf_model_3.pkl")

# ==========================================
# SCALE TEST DATA
# ==========================================

X_test_scaled = scaler.transform(X_test)

# ==========================================
# GET PROBABILITIES
# ==========================================

y_prob = model.predict_proba(X_test_scaled)[:, 1]

# ==========================================
# THRESHOLD TUNING
# ==========================================

threshold_results = []

best_threshold = 0.5
best_f1 = 0

for t in np.arange(0.30, 0.80, 0.05):

    temp_pred = (y_prob >= t).astype(int)

    acc = accuracy_score(y_test, temp_pred)
    prec = precision_score(y_test, temp_pred)
    rec = recall_score(y_test, temp_pred)
    f1 = f1_score(y_test, temp_pred)

    tn, fp, fn, tp = confusion_matrix(y_test, temp_pred).ravel()

    threshold_results.append({
        "Threshold": round(t, 2),
        "Accuracy": acc,
        "Precision": prec,
        "Recall": rec,
        "F1 Score": f1,
        "TN": tn,
        "FP": fp,
        "FN": fn,
        "TP": tp
    })

    if f1 > best_f1:
        best_f1 = f1
        best_threshold = t

# ==========================================
# SAVE RESULTS
# ==========================================

threshold_df = pd.DataFrame(threshold_results)

print(threshold_df)

print("\nBest Threshold:", best_threshold)
print("Best F1 Score:", best_f1)

threshold_df.to_csv("threshold_tuning_results.csv", index=False)

print("\nSaved: threshold_tuning_results.csv")
